<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
       // Artisan::call('backup:run'); 
        return view('home');
    }

    public function db()
    {
       #use Illuminate\Support\Facades\Artisan;
        Artisan::call('backup:run'); 
        return route('home');
    }
    public function databaseBackRun()
    {
       #use Illuminate\Support\Facades\Artisan;
        Artisan::call('backup:run'); 
        return back()->with('success',"Database is Successfully Backup");
    }
    public function dbBackup()
    {
       #use Illuminate\Support\Facades\Artisan;
       // Artisan::call('backup:run'); 
        /*
            dd(Storage::disk('local')->exists('laravel'));
            dd( Storage::disk('local')->get('laravel', 'Contents'));
            if(Storage::disk('public')->exists('Laravel'))
            {
                return "dk";
            }
        */
        //$data['files'] = Storage::allFiles('Laravel');
        $data['files'] = File::allFiles('storage/app/Laravel'); 
        return view('backend.admin.database-backup.database-backup',$data);
    }

    public function dbBackupDownload($getFileName)
    {
        $path = storage_path("app\Laravel/".$getFileName);
        return response()->download($path);
    }
    public function dbBackupDelete($getFileName)
    {
        Storage::delete('Laravel/'.$getFileName);
        return back()->with('success',"Deleted Successfully");
    }

        ///usr/local/bin/ea-php73 /home/milonfeni/https://www.smtradingbd.com/test/path/to/cron/artisan schedule:run >> '/dev/null' 2>&1
}
