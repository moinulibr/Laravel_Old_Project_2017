<?php

namespace App\Model\Backend\Admin\Account;

use Illuminate\Database\Eloquent\Model;

class Account_balance extends Model
{
    //
}
