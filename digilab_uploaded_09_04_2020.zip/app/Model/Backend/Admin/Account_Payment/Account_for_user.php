<?php

namespace App\Model\Backend\Admin\Account_Payment;

use Illuminate\Database\Eloquent\Model;

class Account_for_user extends Model
{
    //
}
