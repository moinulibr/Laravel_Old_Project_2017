<?php

namespace App\Model\Backend\Admin\Account_Payment;

use Illuminate\Database\Eloquent\Model;

class Mobile_banking_company extends Model
{
    //
}
