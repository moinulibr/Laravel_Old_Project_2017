<?php

namespace App\Model\Backend\Admin\Account_Payment;

use Illuminate\Database\Eloquent\Model;

class Payment_method extends Model
{
    //
}
