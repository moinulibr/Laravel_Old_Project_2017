<?php

namespace App\Model\Backend\Admin\AllUser\Supplier;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    //
}
