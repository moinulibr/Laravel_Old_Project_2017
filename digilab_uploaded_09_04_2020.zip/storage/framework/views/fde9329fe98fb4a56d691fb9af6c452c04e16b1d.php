<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
    <div class="mobile-sidebar-header d-md-none">
         <div class="header-logo">
             <a href="/dashboard"><img src="<?php echo e(asset('links')); ?>/img/ebusi-logo.png" alt="logo"></a>
         </div>
    </div>

     <div class="sidebar-menu-content">
         <ul class="nav nav-sidebar-menu sidebar-toggle-view " id="submenu_toggle">
             <li class="nav-item">
                <a href="<?php echo e(route('home')); ?>" class="nav-link"><i class="flaticon-dashboard"></i><span>Dashboard</span></a>
             </li>
 
             <li class="nav-item">
                <a href="<?php echo e(route('dbBackup')); ?>" class="nav-link"><i class="flaticon-dashboard"></i><span>DB Backup</span></a>
             </li>
 
             <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['account']['show'])): ?>
             <?php if(check_menu_button('accounts','view')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.account.index')); ?>" class="nav-link"><i class="fas fa-landmark"></i><span>Accounts</span></a>
                </li>
                <?php endif; ?>  
            <?php endif; ?>  
             
            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['client']['show'])): ?>
            <?php if(check_menu_button('clients','view')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.client.index')); ?>" class="nav-link"><i class="fas fa-street-view"></i><span>Clients</span></a>
                </li>
            <?php endif; ?>
            <?php endif; ?>

            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['supplier']['show'])): ?>
            <?php if(check_menu_button('suppliers','view')): ?> 
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.supplier.index')); ?>" class="nav-link"><i class="fas fa-truck-moving"></i><span>Suppliers</span></a>
                </li>
            <?php endif; ?>
            <?php endif; ?>

            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['product']['show'])): ?>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="fas fa-shopping-basket"></i><span>Products</span></a>
                 <ul class="nav sub-group-menu">
                    <?php if(check_menu_button('products','view')): ?> 
                     <li class="nav-item">
                        <a  href="<?php echo e(route('admin.product.index')); ?>" class=" nav-link"><i class="fas fa-angle-right"></i>All Products</a>
                    </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('product_categories','view')): ?>
                     <li class="nav-item">
                        <a href="<?php echo e(route('admin.product-category.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Products Categories</a>
                     </li>
                    <?php endif; ?>
                 </ul>
             </li>
            <?php endif; ?>
       
            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['transaction']['show'])): ?>
            <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>Transactions</span></a>
                 <ul class="nav sub-group-menu">
                    <?php if(check_menu_button('sales','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-sale.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Sales</a>
                     </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('expenses','view')): ?>
                     <li class="nav-item">
                        <a href="<?php echo e(route('admin.transaction-expense.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Income / Expense</a>
                     </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('purchases','view')): ?>
                    <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-purchase.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Purchases</a>
                    </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('transaction_categories','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-category.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Categories</a>
                     </li>
                    <?php endif; ?>
                 </ul>
             </li>
            <?php endif; ?>
            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['user']['show'])): ?>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="flaticon-multiple-users-silhouette"></i><span>User</span></a>
                 <ul class="nav sub-group-menu">
                    <?php if(check_menu_button('employees','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.employee.index')); ?>"  class="nav-link"><i class="fas fa-angle-right"></i>Users <small>(employees)</small></a>
                     </li>
                    <?php endif; ?>
                 </ul>
             </li>
            <?php endif; ?>

            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['user_role']['show'])): ?>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="flaticon-multiple-users-silhouette"></i><span>User Role Manage</span></a>
                 <ul class="nav sub-group-menu">
                    <?php if(check_menu_button('user_roles','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.user-role.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>User Role</a>
                     </li>
                    <?php endif; ?>
               
                    <?php if(check_menu_button('only_deleloper','view')): ?>
                    <li class="nav-item">
                         <a href="<?php echo e(route('admin.user-role-module.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Role Module & Action</a>
                    </li>
                    <?php endif; ?>

                    <?php if(menuEnableType =="button"): ?>
                        <?php if(check_menu_button('module_action_permissions','view')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.role-module-action-permition.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Module Permission</a>
                        </li>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(check_menu_button('only_deleloper','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.role-menu-title.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>User Role Menu Title</a>
                     </li>
                    <?php endif; ?>

                    <?php if(check_menu_button('menu_title_permissions','view')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.role-menu-title-permition.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Menu Title Permission</a>
                     </li>
                    <?php endif; ?>

                    <?php if(check_menu_button('only_deleloper','view')): ?>
                    <li class="nav-item">
                         <a href="<?php echo e(route('admin.user-role-menu-action.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>User Role Menu Action</a>
                    </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('menu_action_permissions','view')): ?>
                    <li class="nav-item">
                         <a href="<?php echo e(route('admin.role-menu-action-permition.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Menu Action Permission</a>
                    </li>
                   <?php endif; ?>
                    <!----------------------------------------------->
                 </ul>
             </li>
            <?php endif; ?>


            <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['user_role']['show'])): ?>
             <li class="nav-item">
                 <a href="" class="nav-link"><i class="flaticon-settings"></i><span>Settings</span></a>
             </li>
             <?php endif; ?>
             <?php if(MENU_TITLE_CHECK_PERMISSION(menu_titles()['user_role']['show'])): ?>
             <li class="nav-item">
                 <a href="" class="nav-link"><i class="fas fa-dice"></i><span>Add-ons</span></a>
             </li>
             <?php endif; ?>

            
         </ul>
     </div>
 </div><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\new\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>