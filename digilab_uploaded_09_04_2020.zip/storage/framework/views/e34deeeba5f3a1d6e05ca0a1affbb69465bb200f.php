<!doctype html>
<html class="no-js" lang="">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
  
    <!----for title---->
    <title>
        EBUSi &#187;
    </title>
    <!----for title---->

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/style.css">
</head>
<body>
    
<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

<div class="card height-auto">
    <div class="card-body">
        <!--div class="heading-layout1">
            <div class="item-title">
                <h3>Company Details</h3>
            </div>
        </div-->
        <div class="single-info-details">
            <div class="item-img">
                <?php if($client->image): ?>
                <?php if(Storage::disk('public')->exists('user-image/',"{$client->id}".$client->image)): ?>
                <img src="<?php echo e(asset('storage/user-image/'.$client->id)); ?>" alt="" height="250" width="250">
                <?php endif; ?>
                <?php else: ?>
                <img src="<?php echo e(asset('links')); ?>/img/figure/user.jpg" alt="client"height="250" width="250">
            <?php endif; ?>
            </div>
            <div class="item-content">
                <div class="info-table table-responsive">
                    <table class="table text-nowrap">
                        <tbody>
                            <tr>
                                <td>client Name:</td>
                                <td class="font-medium text-dark-medium"><?php echo e(ucfirst($client->name)); ?></td>
                            </tr>
                            <tr>
                                <td>Phone Number:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($client->phone); ?> </td>
                            </tr>
                            <tr>
                                <td>Email:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($client->email); ?> </td>
                            </tr>
                            <tr>
                                <td>Clients Address:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($client->address); ?></td>
                            </tr>
                            <tr>
                                <td>Company Name:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($client->company_name); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card height-auto mg-t-30">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3> <span>Transaction Details </span>
                    </h3>
                </div>
            </div>
            <div class="table-responsive"   >
                <table class="table display  text-nowrap">
                    <thead>
                        <tr>
                            <th>
                                <label class="form-check-label">ID</label>
                            </th>
                            <th>Invoice No.</th>
                            <th>Date</th>
                            <th>Payment From</th>
                            <th>Account No</th>
                            <th>Payable Amount</th>
                            <th>Paid Amount</th>
                            <th>Due Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sale_Finals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <label class="form-check-label">#<?php echo e($loop->index +1); ?></label>
                            </td>
                            <td><?php echo e($item->order_no); ?></td>
                            <td><?php echo e(date('d/m/Y',strtotime($item->sale_date))); ?></td>
                            <td>
                                <?php if($item->account_id): ?>
                                    <?php if($item->account_id == 1): ?> 
                                    <span style="color:green">Cash</span>
                                      <?php else: ?>
                                        <?php if($item->accounts->bank_name != NULL): ?>
                                            <?php echo e($item->accounts->bank_name); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                  <?php endif; ?>
                                
                            </td>
                            <td>
                                <?php if($item->account_id): ?>
                                    <?php if($item->accounts->bank_name != NULL): ?>
                                    <?php echo e($item->accounts->account_name ? $item->accounts->account_name:""); ?> <br/>
                                    <?php echo e($item->accounts->account_no ? $item->accounts->account_no : ''); ?> 
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>৳<?php echo e($item->final_total); ?></td>
                            <td>৳ <?php echo e($item->paid_total); ?></td>
                            <td>৳ <?php echo e($item->final_total - $item->paid_total); ?></td>
                            <td>
                                <?php if($item->payment_status == NULL || $item->payment_status == 'Unpaid'): ?>
                                <span  style="color:red;">Unpaid</span>
                                <?php else: ?>
                                <span  style="color:green;">Paid</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="5" style="text-align:right;">Total sum</th>
                            <th>৳ <?php echo e($payableAmount); ?></th>
                            <th>৳ <?php echo e($paidAmount); ?></th>
                            <th>৳  <?php echo e($payableAmount - $paidAmount); ?></th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!---Table responsive end here ---->
        </div>
    </div>
    <!---card body ---->
</div> 

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->


<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
</body>
</html>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->

<?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/alluser/client/print.blade.php ENDPATH**/ ?>