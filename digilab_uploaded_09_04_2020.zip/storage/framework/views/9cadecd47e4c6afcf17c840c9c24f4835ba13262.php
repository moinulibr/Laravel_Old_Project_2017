<footer class="footer-wrap-layout1">
    <div class="copyright">© 2020 EBUSi a product of <a href="https://rdnetworkbd.com/">RD NETWORK BD</a></div>
</footer><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\new\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>