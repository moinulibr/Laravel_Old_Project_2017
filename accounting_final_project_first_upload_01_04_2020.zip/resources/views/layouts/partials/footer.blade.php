<footer class="footer-wrap-layout1">
    <div class="copyright">© 2020 EBUSi a product of <a href="https://rdnetworkbd.com/">RD NETWORK BD</a></div>
</footer>