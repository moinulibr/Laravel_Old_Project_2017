<?php include '../../session.php';?>
<?php include '../../header.php';?>
<?php include '../../topbar.php';?>
<?php include '../../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Sales</a>
                        </li>
                        <li>Edit Order</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Edit Order</h5>
                            </div>
                        </div>
                        <form class="new-added-form ">
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Order No</label>
                                    <input type="text" placeholder="14953" class="form-control" disabled>
                                </div>
                                 <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Clients</label>
                                    <select class="form-control select2">
                                        <option value="">Select Clients</option>
                                        <option value="1">Jamal Vai</option>
                                        <option value="2">Kamal Vai</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Date Created</label>
                                    <input type="text" placeholder="dd/mm/yyyy" class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                                </div>
                          
                                <div class="table-responsive mg-t-30">
                                    <table class="table display data-table text-nowrap">
                                        <thead>
                                            <tr>
                                                <th><label class="form-check-label">ID</label></th>
                                                <th>Product/Service</th>
                                                <th>Qty</th>
                                                <th>Unit Price</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><label class="form-check-label">#1</label></td>
                                                <td>
                                                    <select class="form-control select2">
                                        	           <option>Please search</option> 
                                        	           <option>Car</option> 
                                        	           <option>Bike</option> 
                                        	           <option>Scooter</option> 
                                        	           <option>Cycle</option> 
                                        	           <option>Horse</option> 
                                        	        </select>
                                                </td>
                                                <td><input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td>৳ 1000.00</td>
                                                <td><a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i></a></td>
                                            </tr>
                                            <tr>
                                                <td><label class="form-check-label">#2</label></td>
                                                <td>
                                                    <select class="form-control select2">
                                        	           <option>Please search</option> 
                                        	           <option>Car</option> 
                                        	           <option>Bike</option> 
                                        	           <option>Scooter</option> 
                                        	           <option>Cycle</option> 
                                        	           <option>Horse</option> 
                                        	        </select>
                                                </td>
                                                <td><input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td>৳ 1000.00</td>
                                                <td><a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i></a></td>
                                            </tr>
                                            <tr class="add-new-line">
                                                <td colspan="6" style="text-align: left;">
                                                    <button class="wperp-btn btn--primary add-line-trigger"><i class="flaticon-add-plus-button"></i>Add Line</button>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Fee</td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Discount value</td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>Total Amount</td>
                                                <td>৳ 2000.00</td>
                                                <td></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Save Change</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->
                
               
<?php include '../../footer.php';?>