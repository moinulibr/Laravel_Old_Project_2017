<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>


            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Category</h3>
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Home</a>
                        </li>
                        <li>Edit Category</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Admit Form Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Add New Category</h3>
                            </div>
                        </div>
                        <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Title :</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Type :</label>
									<label for="exinc-type-2" class="radio-inline">
									    <input type="radio" class="exinc-type" id="exinc-type-1" name="exinc-type" value="1" required="" checked="checked">Income
									    <input type="radio" class="exinc-type" id="exinc-type-2" name="exinc-type" value="2" required="">Expense
									</label>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Color :</label>
                                    <div>
                                        <input type="color" id="head" name="head" value="#e66465">
                                        <label for="head"></label>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Note :</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-12 form-group mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Save Change</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Admit Form Area End Here -->

<?php include '../footer.php';?>