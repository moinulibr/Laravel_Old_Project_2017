


                
            </div><!-- Dashboard Content One End Here (Every Page)-->
            
        </div><!-- Page Area End Here (Side Bar)-->
        <!-- Footer Area Start Here -->
                <footer class="footer-wrap-layout1">
                    <div class="copyright">© 2020 EBUSi a product of <a href="https://rdnetworkbd.com/">RD NETWORK BD</a></div>
                </footer>
                <!-- Footer Area End Here -->
    </div><!-- wrapper End Here (Top Bar)-->
    
    <!-- jquery-->
    <script src="/login/js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="/login/js/plugins.js"></script>
    <!-- Popper js -->
    <script src="/login/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="/login/js/bootstrap.min.js"></script>
    <!-- Counterup Js -->
    <script src="/login/js/jquery.counterup.min.js"></script>
    <!-- Moment Js -->
    <script src="/login/js/moment.min.js"></script>
    <!-- Waypoints Js -->
    <script src="/login/js/jquery.waypoints.min.js"></script>
    <!-- Scroll Up Js -->
    <script src="/login/js/jquery.scrollUp.min.js"></script>
    <!-- Full Calender Js -->
    <script src="/login/js/fullcalendar.min.js"></script>
    <!-- Chart Js -->
    <script src="/login/js/Chart.min.js"></script>
	<!-- Select 2 Js -->
    <script src="/login/js/select2.min.js"></script>
	<!-- Date Picker Js -->
    <script src="/login/js/datepicker.min.js"></script>
    <!-- Data Table Js -->
    <script src="/login/js/jquery.dataTables.min.js"></script>
	<!-- Smoothscroll Js -->
    <script src="/login/js/jquery.smoothscroll.min.html"></script>
	<!-- SummerNote Js -->
    <script src="/login/js/summernote-bs4.min.html"></script>
	<!-- Google Map js -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtmXSwv4YmAKtcZyyad9W7D4AC08z0Rb4"></script>
    <!-- Map Init js -->
    <script src="/login/js/google-marker-map.js"></script>
    <!-- Custom Js -->
    <script src="/login/js/main.js"></script>
    <!-- Google Donut Chart JS-->
     <script src="/login/js/google-donut-chart.js"></script>


</body>

</html>