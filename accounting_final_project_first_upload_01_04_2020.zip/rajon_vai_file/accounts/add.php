<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Accounts</a>
                        </li>
                        <li>Add Accounts</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Add Accounts</h5>
                            </div>
                        </div>
                        <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Accounts Type:</label>
									<label for="exinc-type-2" class="radio-inline">
									    <input type="radio" class="exinc-type" id="exinc-type-1" name="exinc-type" value="1" required="" checked="checked">Cash
									    <input type="radio" class="exinc-type" id="exinc-type-2" name="exinc-type" value="2" required="">Mobile Banking
									    <input type="radio" class="exinc-type" id="exinc-type-3" name="exinc-type" value="2" required="">Bank Account
									</label>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Account Name:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Account No:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Company Name:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Company Address:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Accounts</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->

<?php include '../footer.php';?>