<?php include './session.php';?>
<?php include './header.php';?>
<?php include './topbar.php';?>
<?php include './sidebar.php';?>


            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>EBUSi Add-ons</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Add-ons</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->

                <!-- Social Media Start Here -->
                <div class="row gutters-20">
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="card dashboard-card-seven">
                            <div class="social-media bg-linkedin hover-linked">
                                <div class="media media-none--lg">
                                    <div class="social-icon">
                                        <i class="fas fa-file-invoice-dollar"></i>
                                        <h3 class="add-ons-title">Invoice/Billing</h3>
                                    </div>
                                </div>
                                <div class="add-ons-details">Create invoice & send to client by Email/Printed.</div>
                                <div class="add-ons-footer">
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Add-ons Details</a>
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Active Add-ons</a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="card dashboard-card-seven">
                            <div class="social-media bg-twitter hover-twitter">
                                <div class="media media-none--lg">
                                    <div class="social-icon">
                                        <i class="fab fa-megaport"></i>
                                        <h3 class="add-ons-title">HR & Payroll</h3>
                                    </div>
                                </div>
                                <div class="add-ons-details">Online based HR/Payroll software for employee management</div>
                                <div class="add-ons-footer">
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Add-ons Details</a>
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Active Add-ons</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="card dashboard-card-seven">
                            <div class="social-media bg-twitter hover-twitter">
                                <div class="media media-none--lg">
                                    <div class="social-icon">
                                        <i class="fas fa-calculator"></i>
                                        <h3 class="add-ons-title">Accounting & Inventory</h3>
                                    </div>
                                </div>
                                <div class="add-ons-details">Web based full Accounting & Inventory management system.</div>
                                <div class="add-ons-footer">
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Add-ons Details</a>
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Active Add-ons</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6 col-12">
                        <div class="card dashboard-card-seven">
                            <div class="social-media bg-linkedin hover-linked">
                                <div class="media media-none--lg">
                                    <div class="social-icon">
                                        <i class="fas fa-cart-plus"></i>
                                        <h3 class="add-ons-title">Point Of Sales(POS)</h3>
                                    </div>
                                </div>
                                <div class="add-ons-details">Use barcode management software to maintain your sales.</div>
                                <div class="add-ons-footer">
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Add-ons Details</a>
                                    <a data-year="2018" data-busy="0" data-type="prev" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Active Add-ons</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Social Media End Here -->


<?php include './footer.php';?>