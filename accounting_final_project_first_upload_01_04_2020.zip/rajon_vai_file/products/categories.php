<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <ul>
            <li>
                <a href="../dashboard/index.php">Home</a>
            </li>
            <li>Category</li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="row">
                
                <div class="col-6">
                    <div class="card height-auto mg-t-30">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Add Category</h5>
                            </div>
                        </div>
                            <form class="new-added-form form-inline">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Category Name:</label>
                                            <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Parent Category:</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value=""></option>
                                                <option value="1"></option>
                                            </select>
                                        </div>
                                        <div class="form-group col-12 mg-t-8">
                                            <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Category</button>
                                        </div>
                                    </div>
                                </form>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card height-auto mg-t-30">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>View Category</h5>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input checkAll">
                                                <label class="form-check-label">ID</label>
                                            </div>
                                        </th>
                                        <th>Category Name</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#1</label>
                                            </div>
                                        </td>
                                        <td>Steel Angle</td>
                                        <td>
                                           <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                   <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/accounts/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#2</label>
                                            </div>
                                        </td>
                                        <td>Service</td>
                                        <td>
                                           <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                   <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/accounts/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!---Table responsive end here ---->
                    </div>
                </div><!--col-->
                
            </div><!-- row-->
        </div>
        <!---card body ---->
    </div>
    <!-- Details Area End Here -->  

<?php include '../footer.php';?>