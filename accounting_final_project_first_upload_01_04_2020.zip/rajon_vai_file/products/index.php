<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Home</a>
                        </li>
                        <li>Products</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Teacher Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Products Data</h3>
                            </div>
                             <a href="/login/products/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"><i class="fas fa-plus"></i> Add Products</a>
                        </div>
                        <form class="mg-b-20">
                            <div class="row gutters-8">
                                <div class="col-xl-1 col-md-2 col-5">
                                    <div class="form-group">
                                        <select class="form-control">
                                            <option value="">Bulk Action</option>
                                            <option value="1">Delete</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-1 col-md-1 col-3">
                                    <div class="form-group">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Apply</a>
                                    </div>
                                </div>
                                <div class="col-xl-7 col-md-6 col-4"></div>
                                <div class="col-xl-2 col-md-2 col-8">
                                    <div class="form-group">
                                        <input type="text" placeholder="Search by Title ..." class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-1 col-md-1 col-4">
                                    <div class="form-group float-right">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Search</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input checkAll">
                                                <label class="form-check-label">ID</label>
                                            </div>
                                        </th>
                                        <th>Product Name</th>
                                        <th>Cost Price</th>
                                        <th>Sale Price</th>
                                        <th>Product Category</th>
                                        <th>Product Type</th>
                                        <th>Supplier</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#1</label>
                                            </div>
                                        </td>
                                        <td>Angle 150*150</td>
                                        <td>৳ 120.00</td>
                                        <td>৳ 100.00</td>
                                        <td>Steel Angle</td>
                                        <td>Goods</td>
                                        <td>Alom Shiping</td>
                                         <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/products/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#2</label>
                                            </div>
                                        </td>
                                        <td>AC fixing</td>
                                        <td>৳ 150.00</td>
                                        <td>৳ 200.00</td>
                                        <td>Repair</td>
                                        <td>Service</td>
                                        <td>Rohim Fixing Shop</td>
                                         <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/products/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Teacher Table Area End Here -->

<?php include '../footer.php';?>
