<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Products</a>
                        </li>
                        <li>Edit Product</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Edit Product</h5>
                            </div>
                        </div>
                        <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Product Name :</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Product Type:</label>
                                    <label for="exinc-type-2" class="radio-inline">
									    <input type="radio" class="exinc-type" id="exinc-type-1" name="exinc-type" value="1" required="" checked="checked">Goods
									    <input type="radio" class="exinc-type" id="exinc-type-2" name="exinc-type" value="2" required="">Service
									</label>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Product Category:</label>
                                    <select class="col-xl-8 col-lg-8 col-12 form-control">
                                        <option value="">Steel Angle</option>
                                        <option value="1">Goods</option>
                                    </select>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Cost Price:</label>
                                    <input type="text" placeholder="0.00" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Sale Price:</label>
                                    <input type="text" placeholder="0.00" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Supplier:</label>
                                    <select class="col-xl-8 col-lg-8 col-12 form-control">
                                        <option value="">Supplier Name</option>
                                        <option value="1">Rohim</option>
                                    </select>
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Save Change</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->

<?php include '../footer.php';?>