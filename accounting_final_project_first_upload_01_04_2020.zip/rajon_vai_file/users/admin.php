<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>User</h3>
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">User</a>
                        </li>
                        <li>Admin User</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Teacher Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Admin Data</h5>
                            </div>
                            <a href="/login/users/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"><i class="fas fa-plus"></i> Add Admin</a>
                        </div>
                        <form class="mg-b-20">
                            <div class="row gutters-8">
                                <div class="col-md-1 col-5">
                                    <div class="form-group">
                                        <select class="form-control">
                                            <option value="">Bulk Action</option>
                                            <option value="1">Delete</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 col-3">
                                    <div class="form-group">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Apply</a>
                                    </div>
                                </div>
                                <div class="col-md-7 col-4"></div>
                                <div class="col-md-2 col-8">
                                    <div class="form-group">
                                        <input type="text" placeholder="Search by Title ..." class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-1 col-4">
                                    <div class="form-group float-right">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Search</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input checkAll">
                                                <label class="form-check-label">ID</label>
                                            </div>
                                        </th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>E-mail</th>
                                        <th>Departments</th>
                                        <th>Designation</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#1</label>
                                            </div>
                                        </td>
                                        <td class="text-center"><img src="../img/figure/student2.png" alt="student"></td>
                                        <td>Milon Feni</td>
                                        <td>+ 88 017458755</td>
                                        <td>smtsdsss@gmail.com</td>
                                        <td>Marketing</td>
                                        <td>Head of Marketing</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                                    aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/users/view.php"><i class="fas fa-eye text-dark-pastel-green"></i>View</a>
                                                    <a class="dropdown-item" href="/login/users/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#2</label>
                                            </div>
                                        </td>
                                        <td class="text-center"><img src="../img/figure/student2.png" alt="student"></td>
                                        <td>Mark Willy</td>
                                        <td>+ 123 9988568</td>
                                        <td>kazifahim93@gmail.com</td>
                                        <td>Sales</td>
                                        <td>Head of Sales</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                                    aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/users/view.php"><i class="fas fa-eye text-dark-pastel-green"></i>View</a>
                                                    <a class="dropdown-item" href="/login/users/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Teacher Table Area End Here -->

<?php include '../footer.php';?>
