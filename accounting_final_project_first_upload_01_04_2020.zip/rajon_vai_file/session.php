<?php
// Start the session
session_start();
if (isset($_SESSION["user"])){
	
}
else {
	header('Location: index.php');
}
?>