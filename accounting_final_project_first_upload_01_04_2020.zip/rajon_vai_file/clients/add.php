<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Clients</a>
                        </li>
                        <li>Add Clients</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Add Clients</h5>
                            </div>
                        </div>
                        <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Clients Name:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Phone Number:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Email:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Address:</label>
                                    <textarea class="col-xl-8 col-lg-8 col-12 textarea form-control" name="message" id="form-message" ></textarea>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Company Name:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Password :</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Confirm Password :</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="text-dark-medium" style=" margin-right: 5px; ">Upload Photo (150px X 150px): </label>
                                    <input type="file" class="form-control-file">
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Clients</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->

<?php include '../footer.php';?>