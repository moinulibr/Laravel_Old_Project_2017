<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
      Role Module Update
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">  
   
   <style>
       .margin-left-33{
        margin-left:33%;
       }

       .not_cash{
           display:none;
       }
       .mobile_banking_type{
           display:none;
       }
   </style>
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Module Action Update</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Admin</li>
                    <li>
                        <a href="<?php echo e(route('admin.user-role-module-action.index')); ?>">Module Action View</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->



<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>



<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

    <!-- Add Expense Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Module Action Update</h5>
                </div>
            </div>
        <form action="<?php echo e(route('admin.user-role-module-action.update',$module_action->id)); ?>" method="POST" class="new-added-form form-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Module Name:</label>
                        <select name="user_role_module_id" id="user_role_module_id" class="col-xl-8 col-lg-8 col-12 form-control">
                            <option value="">Select One</option>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($module_action->user_role_module_id == $item->id ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->module_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('user_role_module_id')): ?>
                        <span class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('user_role_module_id')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label class="col-xl-4 col-lg-4 col-12" for="action_name">Module Action Name:</label>
                        <input type="text" value="<?php echo e($module_action->action_name ?? old('action_name')); ?>" id="action_name" name="action_name" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('action_name')): ?>
                        <span class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('action_name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label for="action_checker_route_or_url" class="col-xl-4 col-lg-4 col-12">Action Checker: <small style="color:red;">(Unique*like,url,route)</small></label>
                        <input name="action_checker_route_or_url" id="action_checker_route_or_url" value="<?php echo e($module_action->action_checker_route_or_url ??  old('action_checker_route_or_url')); ?>" type="text" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('action_checker_route_or_url')): ?>
                        <span  role="alert" class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('action_checker_route_or_url')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-12 mg-t-8">
                        <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Update Module Action</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Add Expense Area End Here -->

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>

<script>
    $(document).ready(function(){
        $('.mobile_banking_type').hide(200);
        $('#payment_method_id').on('change',function(){
            let value = $(this).val();
            if(value == 1)
            {
                $('.not_cash').hide(200);
                $('.mobile_banking_type').hide(200);
            }
            else if(value == 2)
            {
                $('.mobile_banking_type').show(200);
                $('.not_cash').show(200);
            }
            else{
                $('.mobile_banking_type').hide(200);
                $('.not_cash').show(200);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/user-role-management/module/module-action-edit.blade.php ENDPATH**/ ?>