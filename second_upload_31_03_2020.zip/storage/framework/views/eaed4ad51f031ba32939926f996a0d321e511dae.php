<!doctype html>
<html class="no-js" lang="">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
  
    <!----for title---->
    <title>
        EBUSi &#187; <?php echo $__env->yieldPushContent('title'); ?>
    </title>
    <!----for title---->

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('links')); ?>/img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/bootstrap.min.css">
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/all.min.css">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/fonts/flaticon.css">

    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/style.css">
    
   <!----custom css link here----->
    <?php echo $__env->yieldPushContent('css'); ?>
   <!----custom css link here----->
</head>
<body>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->

    <div id="wrapper" class="wrapper bg-ash">

       <!-- Header Menu Area Start Here -->
        <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header Menu Area End Here -->
		

        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">


            <!-- Sidebar Area Start Here -->
            <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar Area End Here -->
            
            

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                <!------top page,page identify------->
                        <?php echo $__env->yieldContent('page_identify'); ?>
                <!------top page,page identify------->
                </div>
                <!-- Breadcubs Area End Here --->
               
            <!------------For home page ------------->
                <?php echo $__env->yieldContent('content'); ?>
            <!------------For home page ------------->

            </div><!-- Dashboard Content One End Here (Every Page)-->
            
    </div><!-- Page Area End Here (Side Bar)-->

            <!-- Footer Area Start Here -->
            <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer Area End Here -->


</div><!-- wrapper End Here (Top Bar)-->




  

<!-- jquery-->
<script src="<?php echo e(asset('links')); ?>/js/jquery-3.3.1.min.js"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('links')); ?>/js/plugins.js"></script>
<!-- Popper js -->
<script src="<?php echo e(asset('links')); ?>/js/popper.min.js"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('links')); ?>/js/bootstrap.min.js"></script>
<!-- Counterup Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.counterup.min.js"></script>
<!-- Moment Js -->
<script src="<?php echo e(asset('links')); ?>/js/moment.min.js"></script>
<!-- Waypoints Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.waypoints.min.js"></script>
<!-- Scroll Up Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.scrollUp.min.js"></script>
<!-- Full Calender Js -->
<script src="<?php echo e(asset('links')); ?>/js/fullcalendar.min.js"></script>
<!-- Chart Js -->
<script src="<?php echo e(asset('links')); ?>/js/Chart.min.js"></script>
<!-- Select 2 Js -->
<script src="<?php echo e(asset('links')); ?>/js/select2.min.js"></script>
<!-- Date Picker Js -->
<script src="<?php echo e(asset('links')); ?>/js/datepicker.min.js"></script>
<!-- Data Table Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.dataTables.min.js"></script>
<!-- Smoothscroll Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.smoothscroll.min.html"></script>
<!-- SummerNote Js -->
<script src="<?php echo e(asset('links')); ?>/js/summernote-bs4.min.html"></script>
<!-- Google Map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtmXSwv4YmAKtcZyyad9W7D4AC08z0Rb4"></script>
<!-- Map Init js -->
<script src="<?php echo e(asset('links')); ?>/js/google-marker-map.js"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('links')); ?>/js/main.js"></script>
<!-- Google Donut Chart JS-->
 <script src="<?php echo e(asset('links')); ?>/js/google-donut-chart.js"></script>

<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>




                    <?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/layouts/app.blade.php ENDPATH**/ ?>