<!doctype html>
<html class="no-js" lang="">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
  
    <!----for title---->
    <title>
        EBUSi &#187;
    </title>
    <!----for title---->

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/style.css">
</head>
<body>
    
<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

<div class="card height-auto">
    <div class="card-body">
        <!--div class="heading-layout1">
            <div class="item-title">
                <h3>Company Details</h3>
            </div>
        </div-->
        <div class="single-info-details">
            <div class="item-img">
                <?php if($employee->image): ?>
                <?php if(Storage::disk('public')->exists('user-image/',"{$employee->id}".$employee->image)): ?>
                <img src="<?php echo e(asset('storage/user-image/'.$employee->id)); ?>" alt="" height="250" width="250">
                <?php endif; ?>
                <?php else: ?>
                <img src="<?php echo e(asset('links')); ?>/img/figure/user.jpg" alt="Employee"height="250" width="250">
            <?php endif; ?>
            </div>
            <div class="item-content">
                <div class="info-table table-responsive">
                    <table class="table text-nowrap">
                        <tbody>
                            <tr>
                                <td>Employee Name:</td>
                                <td class="font-medium text-dark-medium">
                                    <?php echo e($employee->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Employee Gender:</td>
                                <td class="font-medium text-dark-medium">
                                    <?php echo e($employee->gender); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Phone Number:</td>
                                <td class="font-medium text-dark-medium"> <?php echo e($employee->phone); ?> </td>
                            </tr>
                            <tr>
                                <td>Email:</td>
                                <td class="font-medium text-dark-medium"> <?php echo e($employee->email); ?></td>
                            </tr>
                            <tr>
                                <td>Blood Group:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($employee->blood_group); ?></td>
                            </tr>
                            <tr>
                                <td>Religion:</td>
                                <td class="font-medium text-dark-medium"><?php echo e($employee->religion); ?></td>
                            </tr>
                            <tr>
                                <td>Address:</td>
                                <td class="font-medium text-dark-medium">
                                    <?php echo e($employee->address); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>ID No:</td>
                                <td class="font-medium text-dark-medium"> <?php echo e($employee->id_no); ?></td>
                            </tr>
                            <tr>
                                <td>User Role:</td>
                                <td class="font-medium text-dark-medium">
                                    <?php if($employee->role_id): ?>
                                    <?php echo e($employee->roles->name); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>BIO:</td>
                                <td class="font-medium text-dark-medium">
                                    <?php echo e(str_limit($employee->bio, 100)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

       
    </div>
    <!---card body ---->
</div> 

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->


<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
</body>
</html>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->

<?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/alluser/employee/print.blade.php ENDPATH**/ ?>