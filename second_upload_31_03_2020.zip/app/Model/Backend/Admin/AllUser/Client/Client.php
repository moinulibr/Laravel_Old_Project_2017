<?php

namespace App\Model\Backend\Admin\AllUser\Client;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    
}
