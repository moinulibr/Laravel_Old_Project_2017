    <?php
    $cart = session()->has('saleCart') ? session()->get('saleCart')  : [];
        //$total = array_sum(array_column($cart,'total_price'));
        $i = 1;
    ?>
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><label class="form-check-label">#<?php echo e($i++); ?></label></td>
    <td>
        <?php echo e($item['product_name']); ?>

        <input type="hidden" name="product_id[]" value="<?php echo e($item['product_id']); ?>">
    </td>
    <td>
        <input name="quantity[]" id="qty-<?php echo e($item['product_id']); ?>" data-unit_price="<?php echo e($item['unit_price']); ?>" value="<?php echo e($item['quantity']); ?>" type="number" step="any" class="clickToGet col-xl-8 col-lg-8 col-12 form-control">
    </td>
    <td>
        <input name="sale_unit_price[]" value="<?php echo e($item['unit_price']); ?>" type="number"  step="any"  id="utp-<?php echo e($item['product_id']); ?>" class="sale_unit_price col-xl-8 col-lg-8 col-12 form-control">
    </td>
    <td>
        <span id="set-<?php echo e($item['product_id']); ?>" class="sum">
            <?php echo e($item['total_price']); ?>

        </span>
    </td>
    <td>
        <?php if(check_menu_button('sales','cancel-single-add-to-cart')): ?>
        <a  data-id="<?php echo e($item['product_id']); ?>" data-url="<?php echo e(route('admin.transaction.sale-add-to-single-remove')); ?>" class="dropdown-item remove_single_sale_cart" href="#"><i class="fas fa-times text-orange-red"></i></a>
        <?php endif; ?>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr class="discount-rate-row">
        <td colspan="3"></td>
        <td>Fee</td>
        <td><input id="fee" name="fee" value="0" type="text"  class="col-xl-8 col-lg-8 col-12 form-control"></td>
        <td></td>
    </tr>
    <tr class="discount-rate-row">
        <td colspan="3"></td>
        <td>Discount value</td>
        <td><input id="discount" name="discount" value="0" type="text" class="col-xl-8 col-lg-8 col-12 form-control"></td>
        <td></td>
    </tr>






    <script>
        $(document).ready(function(){
            let total = 0;
            $('.sum').each(function() 
            {
                total += parseFloat($(this).text());
            })
            $('#sumResult').text(total);
            $('#sumTotalAmount').val(total);

            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);  
        });
    </script>






<?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/sale/add-to-cart/saleAddToCart.blade.php ENDPATH**/ ?>