<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Client View
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">    
   
   <style>
    .margin-left-33{
     margin-left:33%;
    }

    .not_cash{
        display:none;
    }
    .mobile_banking_type{
        display:none;
    }
</style>
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Client Details</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Admin</li>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  



<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>





<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

     <!-- client Details Area Start Here -->
     <div class="card height-auto">
        <div class="card-body">
            <!--div class="heading-layout1">
                <div class="item-title">
                    <h3>Company Details</h3>
                </div>
            </div-->
            <div class="single-info-details">
                <div class="item-img">
                    <?php if($client->image): ?>
                    <?php if(Storage::disk('public')->exists('user-image/',"{$client->id}".$client->image)): ?>
                    <img src="<?php echo e(asset('storage/user-image/'.$client->id)); ?>" alt="" height="250" width="250">
                    <?php endif; ?>
                    <?php else: ?>
                    <img src="<?php echo e(asset('links')); ?>/img/figure/user.jpg" alt="client"height="250" width="250">
                <?php endif; ?>
                </div>
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium">-</h3>
                        <div class="header-elements">
                            <ul>
                                <?php if(check_menu_button('users','user-edit')): ?>
                                <li><a href="<?php echo e(route('admin.userEditFrom',['client',$client->id])); ?>"><i class="far fa-edit"></i></a></li>
                                <?php endif; ?>
                                <?php if(check_menu_button('clients','print-all')): ?>
                                <li><a href="<?php echo e(route('admin.client.print',$client->id)); ?>" class="btnPrint"><i class="fas fa-print"></i></a></li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                    </div>
                    <!--p>Aliquam erat volutpat. Curabiene natis massa sedde lacu stiquen sodale 
               word moun taiery.Aliquam erat volutpaturabiene natis massa sedde  sodale 
               word moun taiery.
            </p-->
                    <div class="info-table table-responsive" >
                        <table class="table text-nowrap">
                            <tbody>
                                <tr>
                                    <td>Client Name:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e(ucfirst($client->name)); ?></td>
                                </tr>
                                <tr>
                                    <td>Phone Number:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($client->phone); ?> </td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($client->email); ?> </td>
                                </tr>
                                <tr>
                                    <td>Clients Address:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($client->address); ?></td>
                                </tr>
                                <tr>
                                    <td>Company Name:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($client->company_name); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card height-auto mg-t-30"  id="toprintDetails">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h3>Transaction Details
                        </h3>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table display  text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input checkAll">
                                        <label class="form-check-label">ID</label>
                                    </div>
                                </th>
                                <th>Invoice No.</th>
                                <th>Date</th>
                                <th>Payment From</th>
                                <th>Account No</th>
                                <th>Payable Amount</th>
                                <th>Paid Amount</th>
                                <th>Due Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sale_Finals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#<?php echo e($loop->index +1); ?></label>
                                    </div>
                                </td>
                                <td><?php echo e($item->order_no); ?></td>
                                <td><?php echo e(date('d/m/Y',strtotime($item->sale_date))); ?></td>
                                <td>
                                  <?php if($item->account_id): ?>
                                    <?php if($item->account_id == 1): ?> 
                                    <span style="color:green">Cash</span>
                                      <?php else: ?>
                                        <?php if($item->accounts->bank_name != NULL): ?>
                                            <?php echo e($item->accounts->bank_name); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                  <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($item->account_id): ?>
                                        <?php if($item->accounts->bank_name != NULL): ?>
                                        <?php echo e($item->accounts->account_name ? $item->accounts->account_name:""); ?> <br/>
                                        <?php echo e($item->accounts->account_no ? $item->accounts->account_no : ''); ?> 
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>৳<?php echo e($item->final_total); ?></td>
                                <td>৳ <?php echo e($item->paid_total); ?></td>
                                <td>৳ <?php echo e($item->final_total - $item->paid_total); ?></td>
                                <td>
                                    <?php if($item->payment_status == NULL || $item->payment_status == 'Unpaid'): ?>
                                    <span  style="color:red;">Unpaid</span>
                                    <?php else: ?>
                                    <span  style="color:green;">Paid</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="5" style="text-align:right;">Total sum</th>
                                <th>৳ <?php echo e($payableAmount); ?></th>
                                <th>৳ <?php echo e($paidAmount); ?></th>
                                <th>৳  <?php echo e($payableAmount - $paidAmount); ?></th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!---Table responsive end here ---->
            </div>
        </div>
        <!---card body ---->
    </div>
    <!-- client Details Area End Here -->    

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->






 <!-- The Modal -->
 <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content modal-sm">
  
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title" style="text-align:center">Delete This Account</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        <!-- Modal body -->
        <div class="modal-body">
            Are You Sure To Delete This?
        </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
          <a class="btn btn-info" id="delete" href="">Yes</a>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
  
      </div>
    </div>
  </div>



<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>
<!-- jquery-->

 
 <script>
    $('.delete').click(function(){
        let url  = $(this).data('url');
        $('#delete').attr("href",url);
    });
</script>


<!--------for Print option ---->
<script src="<?php echo e(asset('links')); ?>/js/print/jquery.printPage.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.btnPrint').printPage();
        });
</script>
<!--------for Print option ---->
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/alluser/client/show.blade.php ENDPATH**/ ?>