<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Sale Create
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      

   <style>
    .margin-left-33{
     margin-left:33%;
    }

    .not_cash{
        display:none;
    }
    .mobile_banking_type{
        display:none;
    }
</style>
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Transaction sale</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Sale create</li>
                    <?php if(check_menu_button('sales','view')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-sale.index')); ?>">Back</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  






<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>



<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

     <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Create Order</h5>
                            </div>
                        </div>
                        <form action="<?php echo e(route('admin.transaction-sale.store')); ?>" method="POST" class="new-added-form ">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Order No</label>
                                    <input type="text" value="<?php echo e($order_id); ?>" class="form-control" disabled>
                                    <input name="order_no" type="hidden" value="<?php echo e($order_id); ?>" class="form-control" >
                                </div>
                                 <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Clients</label>
                                    <select name="client_id" class="form-control select2" required>
                                        <option value="">Select Clients</option>
                                       <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('client_id') == $item->id ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> 
                                    <?php if($errors->has('client_id')): ?>
                                    <span>
                                        <strong style="color:red;"><?php echo e($errors->first('client_id')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Date Created</label>
                                    <input name="sale_date" type="text" required value="<?php echo e(old('sale_date') ?? date('d-m-Y')); ?>" placeholder="dd-mm-yyyy"  class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                                    <?php if($errors->has('sale_date')): ?>
                                    <span>
                                        <strong style="color:red;"><?php echo e($errors->first('sale_date')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div  class="table-responsive" style="margin-left:2%;margin-right:2%;height:50px;">
                                    <?php if(check_menu_button('sales','add-to-cart')): ?>
                                   <div class="form-group" id="selectDiv">
                                    <select   id="product_id"  class="product_id col-xl-10 col-lg-10 col-12 form-control select2" style="margin-left:10%;margin-bottom:2%;" >
                                        <option value="">Select A Product</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                   </div>
                                   <?php endif; ?>
                                </div>

                                <div class="table-responsive">
                                    <table class="table display  text-nowrap">
                                        <thead>
                                            <tr>
                                                <th><label class="form-check-label">ID</label></th>
                                                <th>Product/Service</th>
                                                <th>Qty</th>
                                                <th>Unit Price</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="showResult">
                                            

                                            <tr class="discount-rate-row">
                                                <td colspan="3"></td>
                                                <td>Fee</td>
                                                <td>
                                                    <input id="fee" autocomplete="off" name="fee" value="0" type="number"   step="any"  class="col-xl-8 col-lg-8 col-12 form-control">
                                                </td>
                                                <td></td>
                                            </tr>
                                            <tr class="discount-rate-row">
                                                <td colspan="3"></td>
                                                <td>Discount value</td>
                                                <td>
                                                    <input id="discount" autocomplete="off" name="discount" value="0" type="number"  step="any"  class="col-xl-8 col-lg-8 col-12 form-control">
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3"></td>
                                                <td>Total Amount</td>
                                                <td>৳
                                                     <strong id="sumResult"></strong>
                                                     <input type="hidden" name="final_total" id="sumTotalAmount" value="">
                                                     <input type="hidden" name="total_quantity" id="sumTotalQty" value="">
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                           
                               
                                <div class="form-group col-12 mg-t-8">
                                    <?php if(check_menu_button('sales','store')): ?>
                                    <button style="display:none;"  type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark orderNow ">Order Now</button>
                                    <?php endif; ?>
                                    <?php if(check_menu_button('sales','cancel-all-add-to-cart')): ?>
                                    <a  href="<?php echo e(route('admin.transaction.sale-add-to-cancel-process')); ?>" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Cancel Process</a>
                                    <?php endif; ?>
                                    <?php
                                    $cart = session()->has('saleCart') ? session()->get('saleCart')  : [];
                                    ?>
                                    <?php if(count( $cart)>0): ?>     
                                    <?php if(check_menu_button('sales','show-add-to-cart')): ?>
                                    <a data-url="<?php echo e(route('admin.transaction.sale-add-to-show-cart')); ?>" id="showCart" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Show Cart</a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->


            <div id="getUrl" data-url="<?php echo e(route('admin.transaction.sale-add-to-cart-ajax')); ?>"></div>






<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>


<script type="text/javascript">
    $(document).ready(function(){
        $('.orderNow').hide();
        /*== sale add to cart==*/

        $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

        $('#product_id').on('change',function(e){
            e.preventDefault();
           let product_id = $(this).val();
           let url = $('#getUrl').data('url'); 
                $.ajax({
                    url:url,
                    type:'POST',
                    datatype:'html',
                    cache : false,
                    async: false,
                    data:{product_id},
                    success:function(response)
                    {   
                        $('#showResult').html(response);
                        $('.orderNow').show(); 
 
                    },
                });
        });
            /*== sale add to cart end==*/
            

        /*==sale remove single from add to cart==*/
            $(document).on('click', '.remove_single_sale_cart' ,function(eee){
            eee.preventDefault();
            let url = $(this).data('url');
            let product_id = $(this).data('id');
            $.ajax({
                url:url,
                type:'GET',
                datatype:'html',
                data:{product_id:product_id},
                success:function(response)
                {   
                    $('#showResult').html(response);

                },
            });
        });
        /*==sale remove single from add to cart==*/
    });
</script>

<script>
    $(document).ready(function(){

        $(document).on('keyup , change','.clickToGet, .sale_unit_price, #fee,#discount' ,function(ee){
            ee.preventDefault();
           
            let unit_price = $('.clickToGet').data('unit_price');
            let id = parseInt($(this).attr("id").substr(4));
            let qty = $('#qty-' + id).val();
            let unit_price_custom = $('#utp-' + id).val();
            let sub_total = (unit_price_custom * qty).toFixed(2);
            $("#set-" + id).text(sub_total);
  
            /*
            var sub_total = parseFloat($("#bon_" + id).val());
            var penalty = parseFloat($("#pen_" + id).val());
            var total_salary = salary + bonus - penalty;
            */
            //$("#total_" + id).text(total_salary);

            
            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);


            let total = 0;
            $('.sum').each(function() 
            {
                total += parseFloat($(this).text());
            })


            let fee = 0;
            if(parseFloat($('#fee').val())  > 0)
            {
                fee  =  parseFloat($('#fee').val()).toFixed(2);
            }

            let discount = 0;
            if(parseFloat($('#discount').val())> 0)
            {
                discount = parseFloat($('#discount').val()).toFixed(2);
            }
            
            let toalAmount = (parseFloat(total)  + parseFloat(fee) - parseFloat(discount));
            toalAmount = (toalAmount.toFixed(2));
            $('#sumResult').text(toalAmount);
            $('#sumTotalAmount').val(toalAmount);
        });



            let total = 0;
            $('.sum').each(function() 
            {
                total += parseFloat($(this).text());
            })
            $('#sumResult').text(total);
            $('#sumTotalAmount').val(total);
         

            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);  
           
    });
</script>

<script>
    $(document).ready(function(){
        $('#showCart').on('click',function(e){
            e.preventDefault();
           let url = $(this).data('url'); 
            $.ajax({
                url:url,
                datatype:'html',
                success:function(response)
                {   
                    $('#showResult').html(response);
                    $('.orderNow').show();
                },
            });
        });
    });
</script>

<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/sale/create.blade.php ENDPATH**/ ?>