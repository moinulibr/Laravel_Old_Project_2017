<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       View Invoice
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3> Sales Invoice</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li> Sales Show</li>
                    <?php if(check_menu_button('products','view')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-sale.index')); ?>">Back</a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  



<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Invoice Details</h5>
                </div>
            </div>
            <div class="single-info-details">
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium"></h3>
                        <div class="header-elements">
                            <ul>
                                
                                <li><a href="#"  onclick="javascript:printDiv('toprint')"><i class="fas fa-print"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>


                    <div class="info-table table-responsive"  id="toprint">
                        
                        <div class="order-branding">
                            <div class="right-invoice">INVOICE</div>
                            
                            <h2 class="company-address"><?php echo e(Information::$company_name); ?></h2>
                            <p>
                               <?php echo e(Information::$company_address_raod); ?></br>
                               <?php echo e(Information::$company_address_house); ?></br>
                                Mobile: <?php echo e(Information::$company_mobile_1); ?></br>
                                Mobile: <?php echo e(Information::$company_mobile_2); ?></br>
                                <?php echo e(Information::$company_email); ?>

                            </p>
                        </div>
                        <div class="order-addresses">
                            <div class="billing-address">
                                <h3>Customer:</h3>
                                <p>
                                    
                                <?php echo e($final_sale->users->name); ?>,</br>
                                <?php echo e($final_sale->users->company_name); ?>,</br>
                                <?php echo e($final_sale->users->address); ?></br>
                                Mobile: <?php echo e($final_sale->users->phone ?? "Nill"); ?></br>
                                <?php echo e($final_sale->users->email); ?>

                            </p>
                            </div>
                            <div class="shipping-address">
                            </div>
                            
                            
                            <table class="order-info">
                                <tr>
                                    <th>Order Number:</th>
                                    <td> <?php echo e($final_sale->order_no); ?></td>
                                </tr>
                                <tr>
                                    <th>Order Date:</th>
                                    <td> <?php echo e(date('d-m-Y',strtotime($final_sale->sale_date))); ?></td>
                                </tr>
                                <tr>
                                    <th>Payment Status:</th>
                                    <td>
                                        <?php if($final_sale->payment_status == NULL || $final_sale->payment_status == 'Unpaid'): ?>
                                        <span  style="color:red;">Unpaid</span>
                                        <?php else: ?>
                                        <span  style="color:green;">Paid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <table class="order-items">
                            <thead>
                                <tr>
                                    <th class="product">Description</th>
                                    <th class="qty">Qty</th>
                                    <th class="price">Unit Price</th>
                                    <th class="total">Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sale_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="product">
                                        <?php echo e($item->products->name); ?>

                                        <dl class="meta">
                                            <dt></dt>
                                            <dd></dd>
                                        </dl>
                                    </td>
                                    <td class="qty">
                                        <?php echo e($item->quantity); ?>

                                    </td>
                        
                                    <td class="price">৳ 
                                        <?php echo e($item->unit_price); ?>

                                    </td>
                                    <td class="total">৳
                                        <?php echo e(number_format((float)$item->unit_price * $item->quantity, 2, '.', '')); ?>

                                        <del></del>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot style="text-align: right;">
                                <!-- order_discount removed in WC 2.3, included for backwards compatibility -->
                                <tr class="order-discount">
                                    <th colspan="3">Sub Total:</th>
                                    <td colspan="1"><?php echo e($final_sale->sub_total); ?></td>
                                </tr>
                                <tr class="order-discount">
                                    <th colspan="3">Fee:</th>
                                    <td colspan="1"><?php echo e($final_sale->fee); ?></td>
                                </tr>
                                <tr class="order-discount">
                                    <th colspan="3">Discount:</th>
                                    <td colspan="1"><?php echo e($final_sale->discount); ?></td>
                                </tr>
                                <!-- end order_discount -->
                                <tr class="order-total">
                                    <th colspan="3">Payable Amount:</th>
                                    <td colspan="1"><?php echo e($final_sale->final_total); ?></td>
                                </tr>
                                <tr class="pos_cash-tendered">
                                    <th colspan="3">Paid Amount:</th>
                                    <td colspan="1"><?php echo e($final_sale->paid_total); ?></td>
                                </tr>
                                <tr class="pos_cash-change">
                                    <th colspan="3">Due Amount:</th>
                                    <td colspan="1"><?php echo e($final_sale->final_total - $final_sale->paid_total); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                        <!--h4>Terms & Conditions:</h4>
                        <p>
                            1. Please write a cheque under the name of SM Trading.
                        </p-->
                        <table class="signature">
                            <tr>
                                <td class="signature-left">
                                    Receiver's signature
                                </td>
                                <td class="signature-right">
                                    On behalf of  <?php echo e(Information::$company_name); ?>

                                </td>
                            </tr>
                        </table>
                        <div class="order-notes"></div>
                        <div class="footer">
                            <hr>
                            <p>If you have any inquiry about this, please feel free to contact
                                <br>  <?php echo e(Information::$company_invoice_print_person); ?> ( <?php echo e(Information::$company_invoice_print_person_mobile); ?>)
                                <br> Thank You For Your Business !!</p>
                        </div>
                        
                    </div><!-- Table Content -->
                </div>
            </div>
        </div>
        <!---card body ---->
    </div>
    <!-- Student Details Area End Here -->  

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>



<script>
    function printDiv(divID)
    {
        var divElements = document.getElementById(divID).innerHTML;
        var oldPage = document.body.innerHTML;
        
        document.body.innerHTML = 
        "<html><head><title></title></head><body>" +
        divElements + "</body></html>";

        window.print();
        document.body.innerHTML = oldPage;
    }
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/sale/show.blade.php ENDPATH**/ ?>