<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Expense Invoice
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>  Income / Expense  Invoice </h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Income / Expense</li>
                    <?php if(check_menu_button('expenses','view')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-expense.index')); ?>">Back</a>
                    </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('expenses','create')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-expense.create')); ?>">Create</a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  





<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

        <!-- Student Details Area Start Here -->
        <div class="card height-auto">
            <div class="card-body">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h5>Invoice Details</h5>
                    </div>
                </div>
                <div class="single-info-details">
                    <div class="item-content">
                        <div class="header-inline item-header">
                            <h3 class="text-dark-medium font-medium"></h3>
                            <div class="header-elements">
                                <ul>
                                     
                                    <li><a href="#"  onclick="javascript:printDiv('toprint')"><i class="fas fa-print"></i></a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="info-table table-responsive"  id="toprint">
                            
                            <div class="order-branding">
                                <div class="right-invoice">INVOICE</div>
                                
                                <h2 class="company-address"><?php echo e(Information::$company_name); ?></h2>
                                <p>
                                   <?php echo e(Information::$company_address_raod); ?></br>
                                   <?php echo e(Information::$company_address_house); ?></br>
                                    Mobile: <?php echo e(Information::$company_mobile_1); ?></br>
                                    Mobile: <?php echo e(Information::$company_mobile_2); ?></br>
                                    <?php echo e(Information::$company_email); ?>

                                </p>
                            </div>
                            <div class="order-addresses">
                                <div class="billing-address">
                                    <h3>Pay to:</h3>
                                    <p>
                                  Income / Expense Details
                                </p>
                                </div>
                                <div class="shipping-address">
                                </div>
                                
                                
                                <table class="order-info">
                                    <tr>
                                        <th>Reference Number</th>
                                        <td><?php echo e($final_expense->reference_no); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Reference Date</th>
                                        <td><?php echo e($final_expense->expense_date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php if($final_expense->payment_status == NULL || $final_expense->payment_status == 'Unpaid'): ?>
                                            <span  style="color:red;">Unpaid</span>
                                            <?php else: ?>
                                            <span  style="color:green;">Paid</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    
                                </table>
                            </div>
                            <table class="order-items">
                                <thead>
                                    <tr>
                                        <th class="product">Expense Title</th>
                                        <th class="product">Description</th>
                                        <th class="price">Category</th>
                                        <th class="total">Total Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expense_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product"><?php echo e($item->expense_title); ?>

                                            <dl class="meta">
                                                <dt></dt>
                                                <dd></dd>
                                            </dl>
                                        </td>
                                        <td class="qty" style="text-align:left;"><?php echo e($item->description); ?></td>
                            
                                        <td class="price">
                                            <?php echo e($item->final_expenses->categories->name); ?>

                                            <?php if($item->final_expenses->category_type == "expense"): ?>
                                            <span style="color:red;">
                                                (<?php echo e(ucfirst($item->final_expenses->category_type)); ?>)
                                            </span>
                                                <?php else: ?>
                                                <span style="color:green;">
                                                    (<?php echo e(ucfirst($item->final_expenses->category_type)); ?>)
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="total">৳ <?php echo e($item->final_total); ?>

                                            <del></del>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot style="text-align: right;">
                                    <!-- order_discount removed in WC 2.3, included for backwards compatibility -->
                                    <!-- end order_discount -->
                                    <tr class="order-total">
                                        <th colspan="3">Payable Amount:</th>
                                        <td colspan="1"><?php echo e($final_expense->final_total); ?></td>
                                    </tr>
                                    <tr class="pos_cash-tendered">
                                        <th colspan="3">Paid Amount:</th>
                                        <td colspan="1"><?php echo e($final_expense->paid_total); ?></td>
                                    </tr>
                                    <tr class="pos_cash-change">
                                        <th colspan="3">Due Amount:</th>
                                        <td colspan="1"><?php echo e($final_expense->final_total - $final_expense->paid_total); ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                            <!--h4>Terms & Conditions:</h4>
                            <p>
                                1. Please write a cheque under the name of SM Trading.
                            </p-->
                            <table class="signature">
                                <tr>
                                    <td class="signature-left">
                                        Receiver's signature
                                    </td>
                                    <td class="signature-right">
                                        On behalf of  <?php echo e(Information::$company_name); ?>

                                    </td>
                                </tr>
                            </table>
                            <div class="order-notes"></div>
                            <div class="footer">
                                <hr>
                                <p>If you have any inquiry about this, please feel free to contact
                                    <br>  <?php echo e(Information::$company_invoice_print_person); ?> ( <?php echo e(Information::$company_invoice_print_person_mobile); ?>)
                                    <br> Thank You For Your Business !!</p>
                            </div>
                            
                        </div><!-- Table Content -->
                    </div>
                </div>
            </div>
            <!---card body ---->
        </div>
        <!-- Student Details Area End Here --> 

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>



<script>
    function printDiv(divID)
    {
        var divElements = document.getElementById(divID).innerHTML;
        var oldPage = document.body.innerHTML;
        
        document.body.innerHTML = 
        "<html><head><title></title></head><body>" +
        divElements + "</body></html>";

        window.print();
        document.body.innerHTML = oldPage;
    }
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/expense/show.blade.php ENDPATH**/ ?>