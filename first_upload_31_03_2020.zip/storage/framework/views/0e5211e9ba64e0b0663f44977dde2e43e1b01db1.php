    <?php
    $cart = session()->has('purchaseCart') ? session()->get('purchaseCart')  : [];
        //$total = array_sum(array_column($cart,'total_price'));
        $i = 1;
    ?>
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><label class="form-check-label">#<?php echo e($i++); ?></label></td>
        <td>
            <?php echo e($item['product_name']); ?>

            <input type="hidden" name="product_id[]" value="<?php echo e($item['product_id']); ?>">
        </td>
        <td>
            <input type="text" name="discription[]" class="col-xl-8 col-lg-8 col-12 form-control">
            <?php if($errors->has('discription.*')): ?>
            <ul>
               <?php $__currentLoopData = $errors->get('discription.*'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li><?php echo e($error); ?></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </td>
        <td>
            <input name="quantity[]" id="qty-<?php echo e($item['product_id']); ?>"   value="<?php echo e($item['quantity']); ?>"  step="any"  type="number" class="clickToGet col-xl-8 col-lg-8 col-12 form-control">
        </td>
        <td>
            <input  name="purchase_unit_price[]" value="0" type="number" id="unp-<?php echo e($item['product_id']); ?>"   step="any"  class="clickToGet  purchase_unit_price  col-xl-8 col-lg-8 col-12 form-control">
            
            <input  value="" type="hidden"  class="col-xl-8 col-lg-8 col-12 form-control">
        </td>
        <td>
            <input name="sale_unit_price[]" value="0" type="number"   step="any"  class="col-xl-8 col-lg-8 col-12 form-control">
        </td>
        <td>
            <span id="set-<?php echo e($item['product_id']); ?>"  class="sum"></span>
            <input type="hidden" value="" name="" id="set_val-<?php echo e($item['product_id']); ?>">
        </td>
        <td>
            <?php if(check_menu_button('purchases','cancel-single-add-to-cart-purchase')): ?>
            <a data-id="<?php echo e($item['product_id']); ?>" data-url="<?php echo e(route('admin.transaction.purchase-add-to-single-remove')); ?>" class="dropdown-item remove_single_sale_cart" href="#"><i class="fas fa-times text-orange-red"></i></a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   





    <script>
        /*
        $(document).ready(function(){
            let total = 0;
            $('.sum').each(function() 
            {
                total += parseFloat($(this).val());
            })
            $('#sumResult').text(total);
            $('#sumTotalAmount').val(total);

            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);  
      
        });
        */
    </script>






 <script type="text/javascript">
 /*
    $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

    $(document).ready(function(){
        /*== sale add to cart==*/
        /*
        $('#product_id').on('change',function(e){
            e.preventDefault();
           let product_id = $(this).val();
           let url = $('#getUrl').data('url'); 
            $.ajax({
                url:url,
                type:'GET',
                datatype:'html',
                data:{product_id:product_id},
                success:function(response)
                {   
                    $('#showResult').html(response);
                },
            });
        });
            /*== sale add to cart end==*/


        /*==sale remove single from add to cart==*/
        /*
            $('.remove_single_sale_cart').on('click',function(eee){
            eee.preventDefault();
            let url = $(this).data('url');
            let product_id = $(this).data('id');
            $.ajax({
                url:url,
                type:'GET',
                datatype:'html',
                data:{product_id:product_id},
                success:function(response)
                {   
                    $('#showResult').html(response);
                    console.log(response);
                },
            });
        });
        /*==sale remove single from add to cart==*/
        /*
    }); /*


    $(document).ready(function(){
        $('.clickToGet,#fee,#discount').on('keyup , change',function(ee){
            ee.preventDefault();
            let unit_price = $(this).data('unit_price');
            let qty = $(this).val();
            let id = parseInt($(this).attr("id").substr(4));
            let sub_total = unit_price * qty;
            $("#set-" + id).text(sub_total);
            /*
            var sub_total = parseFloat($("#bon_" + id).val());
            var penalty = parseFloat($("#pen_" + id).val());
            var total_salary = salary + bonus - penalty;
            */
            //$("#total_" + id).text(total_salary);
            /*
            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);


            let total = 0;
            $('.sum').each(function() 
            {
                total += parseFloat($(this).text());
            })


            let fee = 0;
            if(parseInt($('#fee').val())  > 0)
            {
                fee  =  parseInt($('#fee').val());
            }
            let discount = 0;
            if(parseInt($('#discount').val())> 0)
            {
                discount = parseInt($('#discount').val());
            }
            
            let toalAmount = parseInt(total)  + parseInt(fee) - parseInt(discount);
            
           $('#sumResult').text(toalAmount);
            $('#sumTotalAmount').val(toalAmount);

        });


        let total = 0;
        $('.sum').each(function() 
        {
            total += parseFloat($(this).text());
        })
        $('#sumResult').text(total);
        $('#sumTotalAmount').val(total);


            let total_qty = 0;
            $('.clickToGet').each(function() 
            {
                total_qty += parseFloat($(this).val());
            })
            $('#sumTotalQty').val(total_qty);
    });
    */
</script>
<?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/purchase/add-to-cart/purchaseAddToCart.blade.php ENDPATH**/ ?>