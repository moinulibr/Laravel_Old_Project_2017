<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
    <div class="mobile-sidebar-header d-md-none">
         <div class="header-logo">
             <a href="/dashboard"><img src="<?php echo e(asset('links')); ?>/img/ebusi-logo.png" alt="logo"></a>
         </div>
    </div>
     <div class="sidebar-menu-content">
         <ul class="nav nav-sidebar-menu sidebar-toggle-view" id="submenu_toggle">
             <li class="nav-item">
                 <a href="<?php echo e(asset('links')); ?>/dashboard/index.php" class="nav-link"><i class="flaticon-dashboard"></i><span>Dashboard</span></a>
             </li>
             <li class="nav-item">
                 <a href="<?php echo e(route('admin.account.index')); ?>" class="nav-link"><i class="fas fa-landmark"></i><span>Accounts</span></a>
             </li>
             <li class="nav-item">
                 <a href="<?php echo e(route('admin.user.index')); ?>" class="nav-link"><i class="fas fa-street-view"></i><span>Clients</span></a>
             </li>
             <li class="nav-item">
                 <a href="<?php echo e(asset('links')); ?>/supplier/index.php" class="nav-link"><i class="fas fa-truck-moving"></i><span>Suppliers</span></a>
             </li>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="fas fa-shopping-basket"></i><span>Products</span></a>
                 <ul class="nav sub-group-menu">
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.product.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>All Products</a>
                     </li>
                     <li class="nav-item">
                     <a href="<?php echo e(route('admin.product-category.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Products Categories</a>
                     </li>
                 </ul>
             </li>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>Transactions</span></a>
                 <ul class="nav sub-group-menu">
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-sale.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Sales</a>
                     </li>
                     <li class="nav-item">
                     <a href="<?php echo e(route('admin.transaction-expense.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Expense</a>
                     </li>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-purchase.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Purchases</a>
                     </li>
                     <li class="nav-item">
                         <a href="<?php echo e(route('admin.transaction-category.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Categories</a>
                     </li>
                 </ul>
             </li>
             <li class="nav-item sidebar-nav-item">
                 <a href="#" class="nav-link"><i class="flaticon-multiple-users-silhouette"></i><span>User</span></a>
                 <ul class="nav sub-group-menu">
                     <li class="nav-item">
                         <a href="<?php echo e(asset('links')); ?>/users/employee/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Employee</a>
                     </li>
                     <li class="nav-item">
                         <a href="<?php echo e(asset('links')); ?>/users/admin.php" class="nav-link"><i class="fas fa-angle-right"></i>Admin</a>
                     </li>
                     <li class="nav-item">
                         <a href="<?php echo e(asset('links')); ?>/users/manage-role.php" class="nav-link"><i class="fas fa-angle-right"></i>Manage Role</a>
                     </li>
                 </ul>
             </li>
             <li class="nav-item">
                 <a href="<?php echo e(asset('links')); ?>/settings.php" class="nav-link"><i class="flaticon-settings"></i><span>Settings</span></a>
             </li>
             <li class="nav-item">
                 <a href="<?php echo e(asset('links')); ?>/add-ons.php" class="nav-link"><i class="fas fa-dice"></i><span>Add-ons</span></a>
             </li>
             

            
         </ul>
     </div>
 </div><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>