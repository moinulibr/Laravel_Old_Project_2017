<?php

namespace App\Model\Backend\Admin\Account_Payment;

use Illuminate\Database\Eloquent\Model;

class Payment_type extends Model
{
    protected $table = "payment_typies";
}
