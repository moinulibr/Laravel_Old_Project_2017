<?php
namespace App\Information;

class Information{

    static $company_name = "SM Trading";
    static $company_address_raod = "P.C Road, Saraipara,";
    static $company_address_house = "Pahartali, Chittagong - 4217,";
    static $company_mobile_1 = "01728-817223";
    static $company_mobile_2 = "01817-731181";
    static $company_email = "smtradingctg23@gmail.com";
    static $company_invoice_print_person = "Mr. Milon";
    static $company_invoice_print_person_mobile = "01728 817223";
}