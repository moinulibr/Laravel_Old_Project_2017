<?php

namespace App\Http\Controllers\Backend\Admin\AllUser\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['employees'] = User::whereNull('is_deleted')
                                    ->whereNull('user_type_id')
                                    ->latest()->whereNotIn('role_id',[5,6])
                                    ->paginate(30); 
        return view("backend.admin.alluser.employee.index",$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data['employee'] = User::findOrFail($id); 
        return view("backend.admin.alluser.employee.show",$data);
    }

    public function printAll($id)
    {
        $data['employee'] = User::findOrFail($id); 
        return view("backend.admin.alluser.employee.print",$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
