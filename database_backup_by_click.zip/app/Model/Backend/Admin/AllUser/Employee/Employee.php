<?php

namespace App\Model\Backend\Admin\AllUser\Employee;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //
}
