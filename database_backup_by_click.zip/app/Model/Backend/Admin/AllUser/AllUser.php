<?php

namespace App\Model\Backend\Admin\AllUser;

use Illuminate\Database\Eloquent\Model;

class AllUser extends Model
{
    // 
}
