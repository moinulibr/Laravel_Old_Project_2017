<h5 style="color:red;">
    Please Update Product Details with sale unit price
</h5><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/sale/add-to-cart/errorPage.blade.php ENDPATH**/ ?>