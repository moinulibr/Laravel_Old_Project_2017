<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Business Management ERP
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">  
   
   <style>
       .margin-left-33{
        margin-left:33%;
       }

       .not_cash{
           display:none;
       }
       .mobile_banking_type{
           display:none;
       }
   </style>
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Admin Dashboard</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Admin</li>
                    <li>
                        <a href="<?php echo e(route('admin.account.index')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->



<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>



<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

    <!-- Add Expense Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Add Accounts</h5>
                </div>
            </div>
        <form action="<?php echo e(route('admin.account.store')); ?>" method="POST" class="new-added-form form-inline">
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Accounts Type:</label>
                        <label for="exinc-type-2" class="radio-inline">
                        <input type="radio" class="exinc-type" id="exinc-type-1" name="account_type" <?php echo e(old('account_type') =='cash'?'checked':''); ?> value="cash" required="">Cash
                        <input type="radio" class="exinc-type" id="exinc-type-2" name="account_type" <?php echo e(old('account_type') =='mobile banking'?'checked':''); ?> value="mobile banking" required="">Mobile Banking
                        <input type="radio" checked="checked" class="exinc-type" id="exinc-type-3" name="account_type" <?php echo e(old('account_type') =='bank'?'checked':''); ?> value="bank" required="">Bank Account
                        </label>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group mobile_banking_type">
                        <label class="col-xl-4 col-lg-4 col-12" for="mobile_banking_type">Mobile Banking Type:</label>
                        <select name="mobile_banking_type" id="mobile_banking_type"  class="col-xl-8 col-lg-8 col-12 form-control">
                            <option value="">Please Select One</option>
                            <option <?php echo e(old('mobile_banking_type') == "roket"?'selected':''); ?> value="roket">Roket</option>
                            <option <?php echo e(old('mobile_banking_type') == "bkash"?'selected':''); ?> value="bkash">Bkash</option>
                            <option <?php echo e(old('mobile_banking_type') == "nogod"?'selected':''); ?> value="nogod">Nogod</option>
                        </select>
                        <?php if($errors->has('mobile_banking_type')): ?>
                        <span class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('mobile_banking_type')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label class="col-xl-4 col-lg-4 col-12" for="account_name">Account Name:</label>
                        <input type="text" value="<?php echo e(old('account_name')); ?>" id="account_name" placeholder="Account Name" name="account_name" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('account_name')): ?>
                        <span class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('account_name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label for="account_no" class="col-xl-4 col-lg-4 col-12">Account No:</label>
                        <input name="account_no" id="account_no" value="<?php echo e(old('account_no')); ?>" type="text" placeholder="Account No" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('account_name')): ?>
                        <span  role="alert" class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('account_no')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label class="col-xl-4 col-lg-4 col-12" for="bank_name">Bank Name:</label>
                        <input name="bank_name" id="bank_name" value="<?php echo e(old('bank_name')); ?>" type="text" placeholder="Bank Name" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('bank_name')): ?>
                        <span  role="alert" class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('bank_name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group not_cash">
                        <label class="col-xl-4 col-lg-4 col-12" for="bank_address">Bank Address:</label>
                        <input name="bank_address" id="bank_address" value="<?php echo e(old('bank_address')); ?>" type="text" placeholder="Bank Address" class="col-xl-8 col-lg-8 col-12 form-control">
                        <?php if($errors->has('bank_address')): ?>
                        <span  role="alert" class="margin-left-33">
                        <strong style="color:red;"><?php echo e($errors->first('bank_address')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-12 mg-t-8">
                        <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Accounts</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Add Expense Area End Here -->

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>

<script>
    $(document).ready(function(){
        $('.mobile_banking_type').hide(200);
        $('.exinc-type').click(function(){
            let value = $(this).val();
            if(value == 'cash')
            {
                $('.not_cash').hide(200);
                $('.mobile_banking_type').hide(200);
            }
            else if(value == 'mobile banking')
            {
                $('.mobile_banking_type').show(200);
                $('.not_cash').show(200);
            }
            else{
                $('.mobile_banking_type').hide(200);
                $('.not_cash').show(200);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/backend/admin/account/create.blade.php ENDPATH**/ ?>