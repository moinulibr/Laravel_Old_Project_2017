<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Pay Bill
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">  
   <style>
    .margin-left-33{
     margin-left:33%;
    }

    .not_cash{
        display:none;
    }
    .mobile_banking_type{
        display:none;
    }
</style>   
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Purchase Pay bill </h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Bill Payment </li>
                    <?php if(check_menu_button('purchases','view')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-purchase.index')); ?>">Back</a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  





<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

                      <!-- Add Expense Area Start Here -->
                      <div class="card height-auto">
                        <div class="card-body">
                            <div class="heading-layout1">
                                <div class="item-title">
                                    <h5>Purchases Bill Payment</h5>
                                </div>
                            </div>
                            <form action="<?php echo e(route('admin.transaction.purchase.payment-process')); ?>" method="POST" class="new-added-form ">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                                        <label>Reference No</label>
                                        <input type="text" value="<?php echo e($purchase->substr_invoice()); ?>" class="form-control" readonly>
                                        <input name="reference_no" type="hidden" value="<?php echo e($purchase->reference_no); ?>" class="form-control">
                                        <input name="id" type="hidden" value="<?php echo e($purchase->id); ?>" class="form-control">
                                    </div>
                                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                                        <label>Pay to</label>
                                        <input type="text" value="<?php echo e($purchase->users->name); ?>" class="form-control" readonly>
                                        <input name="supplier_id" type="hidden" value="<?php echo e($purchase->supplier_id); ?>" class="form-control">
                                    </div>
                                    
                                    
                                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                                        <label>Payment Date</label>
                                        <input required name="payment_date" type="text" value="<?php echo e(old('payment_date') ?? date('d/m/Y')); ?>" placeholder="dd/mm/yyyy" class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                                        <?php if($errors->has('payment_date')): ?>
                                        <span >
                                        <strong style="color:red;"><?php echo e($errors->first('payment_date')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                                        <label>Payment Type</label>
                                        <select  name="payment_type_id" id="payment_type_id" class="form-control">
                                            <option value="">Select One</option> 
                                            <?php $__currentLoopData = $payment_typies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('payment_type_id') == $item->id  ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e(ucfirst($item->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <?php if($errors->has('payment_date')): ?>
                                        <span >
                                        <strong style="color:red;"><?php echo e($errors->first('payment_date')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                                        <label>Payment Method</label>
                                        <select name="payment_method_id" id="payment_method_id" class="form-control">
                                            <option value="">Select One</option>
                                           <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option <?php echo e(old('payment_method_id') == $item->id ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e(ucfirst($item->name)); ?></option>  
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('payment_method_id')): ?>
                                        <span >
                                        <strong style="color:red;"><?php echo e($errors->first('payment_method_id')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-12 form-group" id="depositTo" style="display:none;">
                                        <label>Bill Payment By:</label>
                                        <select name="account_id"  class="form-control payment_method_option" id="payment_method_option">
                                            <option >None</option> 
                                        </select>
                                        <?php if($errors->has('account_id')): ?>
                                        <span >
                                        <strong style="color:red;"><?php echo e($errors->first('account_id')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <table class="table display text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th><label class="form-check-label">ID</label></th>
                                                    <th>Product/Service</th>
                                                    <th>Description</th>
                                                    <th>Qty</th>
                                                    <th>Unit Price</th>
                                                    <th>Total Amount</th>
                                                    <th>Paid Amount</th>
                                                    <th>Due Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $purchase_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                <td><label class="form-check-label">#<?php echo e($loop->index +1); ?></label></td>
                                                    <td>
                                                        <?php echo e($item->products->name); ?>   
                                                    </td>
                                                    <td> <?php echo e($item->discription); ?> </td>
                                                    <td> <?php echo e($item->quantity); ?> </td>
                                                    <td>৳ <?php echo e($item->unit_price); ?></td>
                                                    <td>৳ <?php echo e($item->quantity * $item->unit_price); ?></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="discount-rate-row">
                                                    <td colspan="4"></td>
                                                    <td>Sub Total</td>
                                                    <td>৳ <?php echo e($purchase_details_amount); ?></td>
                                                    <td colspan="2"></td>
                                                </tr>
                                                <tr class="discount-rate-row">
                                                    <td colspan="4"></td>
                                                    <td>Fee</td>
                                                    <td>৳ <?php echo e($purchase->fee); ?></td>
                                                    <td colspan="2"></td>
                                                    
                                                </tr>
                                                <tr class="discount-rate-row">
                                                    <td colspan="4"></td>
                                                    <td>Discount Amount</td>
                                                    <td>৳ <?php echo e($purchase->discount); ?></td>
                                                    <td colspan="4">
                                                        <strong style="color:green;">Paid Amount 
                                                            <span style="margin-left:3%;color:blue;"> : ৳ <?php echo e($purchase->paid_total); ?> </span>
                                                        </strong>
                                                        <input name="before_paid_total" id="before_paid_total" type="hidden" value="<?php echo e($purchase->paid_total); ?>">
                                                    </td>  
                                                </tr>
                                                </tr>
                                                <tr class="discount-rate-row">
                                                    <td colspan="4"></td>
                                                    <td>Payable Amount</td>
                                                    <td>৳ 
                                                        <strong><?php echo e($purchase->final_total); ?></strong>
                                                        <input id="final_amount" name="final_total"  type="hidden" value="<?php echo e($purchase->final_total); ?>" >
                                                    
                                                        <!----total due now for jquery-->
                                                        <input  id="due_amount_now"   type="hidden" value="<?php echo e($purchase->final_total - $purchase->paid_total); ?>" >
                                                    </td>
                                                    <td style="width:15%;background-color:#ddd;">
                                                        <input  value="<?php echo e(old('paid_total_now')); ?>"  name="paid_total_now" id="paid_amount" type="number" step="any"  class=" form-control" autocomplete="off" style="background-color:#fff;width:80%;">    
                                                        <?php if($errors->has('paid_total_now')): ?>
                                                        <span >
                                                        <strong style="color:red;"><?php echo e($errors->first('paid_total_now')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="background-color:#ddd;">৳ 
                                                       <strong id="due_amount" style="color:red; font-size:16px;"></strong>
                                                    </td>
                                                </tr>
                                                <tr class="discount-rate-row">
                                                    <td>Payment Note</td>
                                                    <td colspan="7">
                                                        <input value="<?php echo e(old('payment_note')); ?>" type="text" name="payment_note" id="" class=" form-control">
                                                        <?php if($errors->has('payment_note')): ?>
                                                        <span >
                                                        <strong style="color:red;"><?php echo e($errors->first('payment_note')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </td>
    
                                                    <!---for jquery check-->
                                                    <input id="payment_status" type="hidden" value="<?php echo e($purchase->payment_status); ?>">
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="form-group col-12 mg-t-8">
                                        <?php if(check_menu_button('purchases','purchase-payment-process')): ?>
                                        <button type="submit" id="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Pay Bill</button>
                                        <?php endif; ?>
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Add Expense Area End Here -->
                

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->







<div id="payment_method_url" data-url="<?php echo e(route('admin.transaction.purchase.receive-payment-method')); ?>"></div>

<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>



 <script>
    $(document).ready(function(){
        $('#paid_amount').on('keyup',function(){

            //due_amount
            let finalAmount =  $('#due_amount_now').val();
            let paidAmount =  $('#paid_amount').val();
            let dueAmount = finalAmount - paidAmount;
            dueAmount =  parseFloat(dueAmount).toFixed(2);
            $('#due_amount').text(dueAmount);

            /*
            let paidingAmount =  $('#paid_amount').val();
            let totalOrderAmount =  $('#final_amount').val();
            let beforePaid =  $('#before_paid_total').val();
            let nowDueamount = totalOrderAmount - beforePaid;
            if(paidingAmount <= dueAmount)
            {
                $('#due_amount').text(paidingAmount);
                $('#paid_amount').val(paidingAmount); 
            }else{
                $('#paid_amount').val(nowDueamount); 
                $('#due_amount').text(nowDueamount);  
            }
            */
        });
    


       let finalAmount =  $('#due_amount_now').val();
       let paidAmount =  $('#paid_amount').val();
       let dueAmount = finalAmount - paidAmount;
       dueAmount =  parseFloat(dueAmount).toFixed(2);
        $('#due_amount').text(dueAmount);


        let totalOrderAmount =  $('#final_amount').val();
        let beforePaid =  $('#before_paid_total').val();
        let payment_status =  $('#payment_status').val();
        if(totalOrderAmount == beforePaid ||  payment_status=='Paid')
        {
            $('#paid_amount').attr('disabled','disabled');  
            $('#submit').attr('disabled','disabled');  
        }
    });
</script>


<script>
    $(document).ready(function(){
        $('#payment_method_id').on('change',function(e){
            e.preventDefault();
           let url = $('#payment_method_url').data('url'); 
           let payment_method = $(this).val();
            $.ajax({
                url:url,
                datatype:'html',
                data:{payment_method:payment_method},
                success:function(response)
                {   
                   $('#payment_method_option').html(response);
                   if(response !="")
                   {
                    $('#depositTo').show(100);
                   }
                   else{
                    $('#depositTo').hide(100);
                   }
                },
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/purchase/pay-bill.blade.php ENDPATH**/ ?>