<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Create Client
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Client Dashboard</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Client</li>
                    <li>
                        <a href="<?php echo e(route('admin.user.index')); ?>">Back</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  




<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!-- page content  Start Here -->
 
     <!-- Add Expense Area Start Here -->
     <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Add Clients</h5>
                </div>
            </div>
            <form class="new-added-form form-inline">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Clients Name:</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Phone Number:</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Email:</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Address:</label>
                        <textarea class="col-xl-8 col-lg-8 col-12 textarea form-control" name="message" id="form-message" ></textarea>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Company Name:</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Password :</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="col-xl-4 col-lg-4 col-12">Confirm Password :</label>
                        <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                        <label class="text-dark-medium" style=" margin-right: 5px; ">Upload Photo (150px X 150px): </label>
                        <input type="file" class="form-control-file">
                    </div>
                    <div class="form-group col-12 mg-t-8">
                        <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Clients</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Add Expense Area End Here -->   
 <!-- page content  End Here -->
<!--#*********************************************************End Page content here*****************************************************************#-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>
   
<!-- jquery-->
<script src="<?php echo e(asset('links')); ?>/js/jquery-3.3.1.min.js"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('links')); ?>/js/main.js"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('links')); ?>/js/bootstrap.min.js"></script>
<!-- Scroll Up Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.scrollUp.min.js"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('links')); ?>/js/plugins.js"></script>
<!-- Smoothscroll Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.smoothscroll.min.html"></script>

<!-- Popper js -->
<script src="<?php echo e(asset('links')); ?>/js/popper.min.js"></script>

<!-- Counterup Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.counterup.min.js"></script>
<!-- Moment Js -->
<script src="<?php echo e(asset('links')); ?>/js/moment.min.js"></script>
<!-- Waypoints Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.waypoints.min.js"></script>

<!-- Full Calender Js -->
<script src="<?php echo e(asset('links')); ?>/js/fullcalendar.min.js"></script>
<!-- Chart Js -->
<script src="<?php echo e(asset('links')); ?>/js/Chart.min.js"></script>
<!-- Select 2 Js -->
<script src="<?php echo e(asset('links')); ?>/js/select2.min.js"></script>
<!-- Date Picker Js -->
<script src="<?php echo e(asset('links')); ?>/js/datepicker.min.js"></script>
<!-- Data Table Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.dataTables.min.js"></script>

<!-- SummerNote Js -->
<script src="<?php echo e(asset('links')); ?>/js/summernote-bs4.min.html"></script>
<!-- Google Map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtmXSwv4YmAKtcZyyad9W7D4AC08z0Rb4"></script>
<!-- Map Init js -->
<script src="<?php echo e(asset('links')); ?>/js/google-marker-map.js"></script>


<!-- Google Donut Chart JS-->
 <script src="<?php echo e(asset('links')); ?>/js/google-donut-chart.js"></script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/backend/admin/alluser/client/create.blade.php ENDPATH**/ ?>