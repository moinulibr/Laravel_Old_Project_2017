<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       User <?php echo e($user_type); ?> Update
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">    
   
   <style>
    .margin-left-33{
     margin-left:33%;
    }

    .not_cash{
        display:none;
    }
    .mobile_banking_type{
        display:none;
    }

    .employee{
        display: none;
    }
    .supplier{
        display: none;
    }
    .client{
        display: none;
    }
</style>
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Admin Dashboard</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Admin</li>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  



<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>





<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

     <!-- Add New Area Start Here -->
     <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title"> 
                    <h5>Add <?php echo e(ucfirst($user_type)); ?></h5>
                </div>
            </div>
            <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="POST" class="new-added-form" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label> Name *</label>
                        <input name="name" value="<?php echo e($user->name ?? old('name')); ?>"  type="text" placeholder="" class="form-control">
                        <?php if($errors->has('name')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>E-Mail</label>
                        <input name="email" value="<?php echo e($user->email ?? old('email')); ?>" type="email" placeholder="" class="form-control">
                        <?php if($errors->has('email')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Phone</label>
                        <input name="phone" value="<?php echo e($user->phone ??  old('phone')); ?>" type="text" placeholder="" class="form-control">
                        <?php if($errors->has('phone')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('phone')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Phone (2)</label>
                        <input name="phone_2" value="<?php echo e($user->phone_2 ??  old('phone_2')); ?>" type="text" placeholder="" class="form-control">
                        <?php if($errors->has('phone_2')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('phone_2')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>User Role</label>
                        <select id="role_id" name="role_id" class="select2">
                            <option value="">Select User Role</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option  <?php echo e($user->role_id == $item->id ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('role_id')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('role_id')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Address</label>
                        <input name="address" value="<?php echo e($user->address ?? old('address')); ?>" type="text" placeholder="" class="form-control">
                        <?php if($errors->has('address')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('address')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <?php if((Auth::user()->id == $user->id) || Auth::user()->role_id == 1): ?>
                        <div class="col-xl-3 col-lg-6 col-12 form-group">
                            <label>Password</label>
                            <input name="password" type="text" placeholder="" class="form-control">
                                <?php if($errors->has('password')): ?>
                                <span  role="alert" >
                                <strong style="color:red;"><?php echo e($errors->first('password')); ?></strong>
                                </span>
                                <?php endif; ?>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-12 form-group">
                            <label>Confirm Password</label>
                            <input name="password_confirmation" type="text" placeholder="" class="form-control">
                            <?php if($errors->has('password_confirmation')): ?>
                            <span  role="alert" >
                            <strong style="color:red;"><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                <!--Only Employee start--->
                <?php if($user_type == 'employee'): ?>
                    <div class="col-xl-3 col-lg-6 col-12 form-group ">
                        <label>ID No</label>
                        <input name="id_no" value="<?php echo e($user->id_no ?? old('id_no')); ?>" type="text" placeholder="" class="form-control">
                        <?php if($errors->has('id_no')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('id_no')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Gender *</label>
                        <select name="gender" class="select2">
                            <option  value="">Please Select Gender *</option>
                            <option <?php echo e($user->gender == 'Male' ?'selected':''); ?> value="Male">Male</option>
                            <option <?php echo e($user->gender == 'Female' ?'selected':''); ?> value="Female">Female</option>
                            <option <?php echo e($user->gender == 'Others' ?'selected':''); ?> value="Others">Others</option>
                        </select>
                        <?php if($errors->has('gender')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('gender')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Blood Group *</label>
                        <select name="blood_group" class="select2">
                            <option value="">Please Select Group *</option>
                            <option <?php echo e($user->blood_group == 'A+' ?'selected':''); ?>  value="A+">A+</option>
                            <option <?php echo e($user->blood_group == 'A-' ?'selected':''); ?>  value="A-">A-</option>
                            <option <?php echo e($user->blood_group == 'B+' ?'selected':''); ?>  value="B+">B+</option>
                            <option <?php echo e($user->blood_group == 'B-' ?'selected':''); ?>  value="B-">B-</option>
                            <option <?php echo e($user->blood_group == 'AB+' ?'selected':''); ?>  value="AB+">AB+</option>
                            <option <?php echo e($user->blood_group == 'AB-' ?'selected':''); ?>  value="AB-">AB-</option>
                            <option <?php echo e($user->blood_group == 'O+' ?'selected':''); ?>  value="O+">O+</option>
                            <option <?php echo e($user->blood_group == 'O-' ?'selected':''); ?>  value="O-">O-</option>
                        </select>
                        <?php if($errors->has('blood_group')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('blood_group')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Religion *</label>
                        <select name="religion" class="select2">
                            <option value="">Please Select Religion *</option>
                            <option <?php echo e($user->religion == 'Islam' ?'selected':''); ?>  value="Islam">Islam</option>
                            <option <?php echo e($user->religion == 'Hindu' ?'selected':''); ?> value="Hindu">Hindu</option>
                            <option <?php echo e($user->religion == 'Christian' ?'selected':''); ?> value="Christian">Christian</option>
                            <option <?php echo e($user->religion == 'Buddish' ?'selected':''); ?> value="Buddish">Buddish</option>
                            <option <?php echo e($user->religion == 'Others' ?'selected':''); ?> value="Others">Others</option>
                        </select>
                        <?php if($errors->has('religion')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('religion')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6 col-12 form-group ">
                        <label>Short BIO</label>
                        <textarea class="textarea form-control" name="bio" id="form-message" cols="10" rows="9"><?php echo e($user->bio); ?></textarea>
                    </div>
                    <?php endif; ?>
                    <!--Only Employee end--->


                     <!--Only supplier  client start--->
                    <?php if($user_type == 'supplier' || $user_type == 'client'): ?>
                        <div class="col-xl-3 col-lg-6 col-12 form-group ">
                            <label>Company Name</label>
                            <input name="company_name" value="<?php echo e($user->company_name ?? old('company_name')); ?>" type="text" placeholder="Company Name" class="form-control">
                            <?php if($errors->has('company_name')): ?>
                            <span  role="alert" >
                            <strong style="color:red;"><?php echo e($errors->first('company_name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                     <!--Only supplier  client end--->


                    <div class="col-lg-12 col-12 form-group mg-t-30">
                        <label class="text-dark-medium">Upload Photo (150px X 150px): </label>
                        <input name="image" type="file" class="form-control-file">
                        <?php if($errors->has('image')): ?>
                        <span  role="alert" >
                        <strong style="color:red;"><?php echo e($errors->first('image')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <input type="hidden" name="user_type" id="" value="<?php echo e($user_type); ?>">
                    <div class="col-12 form-group mg-t-8">
                    <?php if(check_menu_button('users','update')): ?>
                        <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Update <?php echo e(ucfirst($user_type)); ?></button>
                    <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Add New Teacher Area End Here -->

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->






 <!-- The Modal -->
 <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content modal-sm">
  
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title" style="text-align:center">Delete This Account</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        <!-- Modal body -->
        <div class="modal-body">
            Are You Sure To Delete This?
        </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
          <a class="btn btn-info" id="delete" href="">Yes</a>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
  
      </div>
    </div>
  </div>



<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>  
<!-- jquery-->

 
<script>
    $(document).ready(function(){
        $('.mobile_banking_type').hide(200);
        $('#role_id').on('change',function(){
            let value = $(this).val();
            if(value == 1)
            {
                $('.not_cash').hide(200);
                $('.mobile_banking_type').hide(200);
            }
            else if(value == 2)
            {
                $('.mobile_banking_type').show(200);
                $('.not_cash').show(200);
            }
            else{
                $('.mobile_banking_type').hide(200);
                $('.not_cash').show(200);
            }
        });
    });
</script>


 
 <script>
    $('.delete').click(function(){
        let url  = $(this).data('url');
        $('#delete').attr("href",url);
    });
</script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/alluser/form/edit.blade.php ENDPATH**/ ?>