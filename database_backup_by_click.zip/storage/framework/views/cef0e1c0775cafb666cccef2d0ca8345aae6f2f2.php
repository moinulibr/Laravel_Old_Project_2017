<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Business Management ERP
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Admin Dashboard</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Admin</li>
                    <li>
                        <a href="<?php echo e(route('admin.account.index')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  






<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Account Details</h5>
                </div>
            </div>
            <div class="single-info-details">
                <!--div class="item-img">
                    <img src="../img/figure/student1.jpg" alt="student">
                </div-->
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium">-</h3>
                        <div class="header-elements">
                            <ul>
                                <li><a href="<?php echo e(route('admin.account.edit',$account->id)); ?>"><i class="far fa-edit"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <!--p>Aliquam erat volutpat. Curabiene natis massa sedde lacu stiquen sodale 
               word moun taiery.Aliquam erat volutpaturabiene natis massa sedde  sodale 
               word moun taiery.
            </p-->
                    <div class="info-table table-responsive">
                        <table class="table text-nowrap">
                            <tbody>
                                <tr>
                                    <td>Account Type :</td>
                                    <td class="font-medium text-dark-medium">
                                        <?php if($account->account_type == 'mobile banking'): ?>
                                        <span style="color:green;">
                                            <?php echo e(ucfirst($account->mobile_banking_type)); ?>

                                        </span>
                                            <?php else: ?>
                                            <?php echo e(ucfirst($account->account_type)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php if($account->account_type != 'cash'): ?>
                                <tr>
                                    <td>Account Name:</td>
                                    <td class="font-medium text-dark-medium">
                                        <?php echo e(ucfirst($account->account_name)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <tr>
                                        <td>Account No :</td>
                                        <td class="font-medium text-dark-medium">
                                            <?php echo e(ucfirst($account->account_no)); ?>

                                        </td>
                                    </tr>
                                    <td>Bank Name :</td>
                                    <td class="font-medium text-dark-medium">
                                        <?php echo e(ucfirst($account->bank_name)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Bank Address :</td>
                                    <td class="font-medium text-dark-medium">
                                        <?php echo e(ucfirst($account->bank_address)); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card height-auto mg-t-30">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h5>Transaction Details</h5>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table display data-table text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input checkAll">
                                        <label class="form-check-label">ID</label>
                                    </div>
                                </th>
                                <th>Invoice No.</th>
                                <th>Date</th>
                                <th>Pay to/Receive from</th>
                                <th>Amount in</th>
                                <th>Amount out</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#1</label>
                                    </div>
                                </td>
                                <td>125487</td>
                                <td>02/10/2019</td>
                                <td>SIMEX Bangladesh</td>
                                <td>৳100.00</td>
                                <td>৳0.00</td>
                                <td>Income</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#2</label>
                                    </div>
                                </td>
                                <td>120487</td>
                                <td>02/10/2019</td>
                                <td>Shipping Yeard</td>
                                <td>৳0.00</td>
                                <td>৳50.00</td>
                                <td>Expenses</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#3</label>
                                    </div>
                                </td>
                                <td>120487</td>
                                <td>02/10/2019</td>
                                <td>Employee</td>
                                <td>৳0.00</td>
                                <td>৳50.00</td>
                                <td>Expenses</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Total sum</td>
                                <td>৳100</td>
                                <td>৳50</td>
                                <td>৳50</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!---Table responsive end here ---->
            </div>
        </div>
        <!---card body ---->
    </div>
    <!-- Student Details Area End Here -->  

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/backend/admin/account/show.blade.php ENDPATH**/ ?>