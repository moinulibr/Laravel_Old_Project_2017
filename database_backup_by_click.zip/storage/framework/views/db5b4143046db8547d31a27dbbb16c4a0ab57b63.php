<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
       Business Management ERP
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Transaction Category Dashboard</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Transaction Category</li>
                    <li>
                        <a href="../dashboard/index.php">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  






<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

    
    <!-- Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            
        <div class="row">
            <div class="col-6">
            
            <div class="card height-auto mg-t-30">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h5>Add Category</h5>
                    </div>
                </div>
                    <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Category Name:</label>
                                    <input type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                </div>
                                <div class="col-xl-12 col-lg-12 col-12 form-group">
                                    <label class="col-xl-4 col-lg-4 col-12">Category Type:</label>
									<label for="exinc-type-2" class="radio-inline">
									    <input type="radio" class="exinc-type" id="exinc-type-1" name="exinc-type" value="1" required="" checked="checked">Income
									    <input type="radio" class="exinc-type" id="exinc-type-2" name="exinc-type" value="2" required="">Expense
									</label>
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Category</button>
                                </div>
                            </div>
                        </form>
                
            </div>
            
            </div>
            <div class="col-6">
                
            <div class="card height-auto mg-t-30">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h5>View Categories</h5>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table display data-table text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input checkAll">
                                        <label class="form-check-label">ID</label>
                                    </div>
                                </th>
                                <th>Category Name</th>
                                <th>Category Type</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#1</label>
                                    </div>
                                </td>
                                <td>Steel Angle</td>
                                <td>Income </td>
                                <td>
                                   <div class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                           <span class="flaticon-more-button-of-three-dots"></span>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="/login/accounts/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#2</label>
                                    </div>
                                </td>
                                <td>DESCO Bill</td>
                                <td>Expense</td>
                                <td>
                                   <div class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                           <span class="flaticon-more-button-of-three-dots"></span>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="/login/accounts/edit.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!---Table responsive end here ---->
            </div>
            
            
            </div><!--col-->
            </div><!-- row-->
            
        </div>
        <!---card body ---->
    </div>
    <!-- Details Area End Here --> 

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>
   
<!-- jquery-->
<script src="<?php echo e(asset('links')); ?>/js/jquery-3.3.1.min.js"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('links')); ?>/js/main.js"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('links')); ?>/js/bootstrap.min.js"></script>
<!-- Scroll Up Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.scrollUp.min.js"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('links')); ?>/js/plugins.js"></script>
<!-- Smoothscroll Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.smoothscroll.min.html"></script>

<!-- Popper js -->
<script src="<?php echo e(asset('links')); ?>/js/popper.min.js"></script>

<!-- Counterup Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.counterup.min.js"></script>
<!-- Moment Js -->
<script src="<?php echo e(asset('links')); ?>/js/moment.min.js"></script>
<!-- Waypoints Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.waypoints.min.js"></script>

<!-- Full Calender Js -->
<script src="<?php echo e(asset('links')); ?>/js/fullcalendar.min.js"></script>
<!-- Chart Js -->
<script src="<?php echo e(asset('links')); ?>/js/Chart.min.js"></script>
<!-- Select 2 Js -->
<script src="<?php echo e(asset('links')); ?>/js/select2.min.js"></script>
<!-- Date Picker Js -->
<script src="<?php echo e(asset('links')); ?>/js/datepicker.min.js"></script>
<!-- Data Table Js -->
<script src="<?php echo e(asset('links')); ?>/js/jquery.dataTables.min.js"></script>

<!-- SummerNote Js -->
<script src="<?php echo e(asset('links')); ?>/js/summernote-bs4.min.html"></script>
<!-- Google Map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtmXSwv4YmAKtcZyyad9W7D4AC08z0Rb4"></script>
<!-- Map Init js -->
<script src="<?php echo e(asset('links')); ?>/js/google-marker-map.js"></script>


<!-- Google Donut Chart JS-->
 <script src="<?php echo e(asset('links')); ?>/js/google-donut-chart.js"></script>
<?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon Vai\project_new\resources\views/backend/admin/transaction/transaction-category/index.blade.php ENDPATH**/ ?>