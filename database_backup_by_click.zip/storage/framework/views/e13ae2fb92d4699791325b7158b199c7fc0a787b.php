<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="EBUSi" />
<meta name="description" content="Business Management System" />
<meta name="developer" content="www.rdnetworkbd.com" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>EBUSi - Business Management Syatem</title>

<!-- favicon icon -->
<link rel="shortcut icon" href="https://ebusi.rdnetworkbd.com/images/favicon.png" />

<!-- inject css start -->
<!--== bootstrap -->
<link href="https://ebusi.rdnetworkbd.com/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Cabin:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<!--== animate -->
<link href="https://ebusi.rdnetworkbd.com/css/animate.css" rel="stylesheet" type="text/css" />
<!--== fontawesome -->
<link href="https://ebusi.rdnetworkbd.com/css/fontawesome-all.css" rel="stylesheet" type="text/css" />
<!--== line-awesome -->
<link href="https://ebusi.rdnetworkbd.com/css/line-awesome.min.css" rel="stylesheet" type="text/css" />
<!--== magnific-popup -->
<link href="https://ebusi.rdnetworkbd.com/css/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />
<!--== owl-carousel -->
<link href="https://ebusi.rdnetworkbd.com/css/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<!--== base -->
<link href="https://ebusi.rdnetworkbd.com/css/base.css" rel="stylesheet" type="text/css" />
<!--== shortcodes -->
<link href="https://ebusi.rdnetworkbd.com/css/shortcodes.css" rel="stylesheet" type="text/css" />
<!--== default-theme -->
<link href="https://ebusi.rdnetworkbd.com/css/style.css" rel="stylesheet" type="text/css" />
<!--== responsive -->
<link href="https://ebusi.rdnetworkbd.com/css/responsive.css" rel="stylesheet" type="text/css" />
<!--== color-customizer -->
<link href="https://ebusi.rdnetworkbd.com/css/theme-color/color-5.css" data-style="styles" rel="stylesheet">
<link href="https://ebusi.rdnetworkbd.com/css/color-customize/color-customizer.css" rel="stylesheet" type="text/css" />
<!-- inject css end -->

</head>

<body class="home">

<!-- page wrapper start -->

<div class="page-wrapper">

<!-- preloader start -->

<div id="ht-preloader">
  <div class="loader clear-loader">
    <div class="loader-box"></div>
    <div class="loader-box"></div>
    <div class="loader-box"></div>
    <div class="loader-box"></div>
	<div class="loader-box"></div>
    <div class="loader-wrap-text">
      <div class="text"><span>E</span><span>B</span><span>U</span><span>S</span><span>i</span><!--span>N</span><span>O</span-->
      </div>
    </div>
  </div>
</div>

<!-- preloader end -->


<!--header start-->

<header id="site-header" class="header">
  <div class="container">
    <div id="header-wrap">
      <div class="row">
        <div class="col-lg-12">
          <!-- Navbar -->
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand logo" href="index.php">
              <img id="logo-img" class="img-center" src="https://ebusi.rdnetworkbd.com/images/ebusi-logo.svg" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"> 
			<span></span>
            <span></span>
            <span></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <!-- Left nav -->
              <ul id="main-menu" class="nav navbar-nav ml-auto mr-auto">
                <li class="nav-item"> <a class="nav-link active" href="https://ebusi.rdnetworkbd.com/index.php"><i class="fas fa-home"></i></a></li>
				<li class="nav-item"> <a class="nav-link" href="#">EBUSi</a>
                    <ul>
                      <li><a href="https://ebusi.rdnetworkbd.com/invoice-billing.php">Invoice/Billing Software</a></li>
                      <li><a href="https://ebusi.rdnetworkbd.com/hr-payroll.php">HR & Payroll Software</a></li>
					  <li><a href="https://ebusi.rdnetworkbd.com/accounting-inventory.php">Accounting & Inventory Software</a></li>
					  <li><a href="https://ebusi.rdnetworkbd.com/pos-php">Point Of Sales(POS) Software</a></li>
                    </ul>
                </li>
				<li class="nav-item"> <a class="nav-link" href="https://www.rdnetworkbd.com/about-us.php">About</a></li>
				<li class="nav-item"> <a class="nav-link" href="https://www.rdnetworkbd.com/contact.php">Contact</a></li>
              </ul>
            </div>
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                <a class="btn btn-white btn-sm" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                 <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <?php else: ?>
                    <a class="btn btn-white btn-sm" href="" data-text="Login">
                        <span>L</span><span>o</span><span>g</span><span>i</span><span>n</span>
                    </a>

                        

                <?php endif; ?>
            <?php endif; ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>

<!--header end-->













<!--page title start-->

<section class="page-title o-hidden pos-r md-text-center" data-bg-color="#fbf3ed">
  <canvas id="confetti"></canvas>
  <div class="container">
    <div class="row align-items-center">
      <!--div class="col-lg-7 col-md-12">
        <h1 class="title"><span>L</span>ogin</h1>
        <p>We're Building Modern And High Software</p>
      </div>
      <div class="col-lg-5 col-md-12 text-lg-right md-mt-3">
        <nav aria-label="breadcrumb" class="page-breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Login</li>
          </ol>
        </nav>
      </div-->
    </div>
  </div>
  <div class="page-title-pattern"><img class="img-fluid" src="https://ebusi.rdnetworkbd.com/images/bg/11.png" alt=""></div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--login start-->

<section class="login" style="margin-top: -140px;padding-bottom: 100px;">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6 col-md-12">
          <!---changes-->
        <img class="img-fluid" src="<?php echo e(asset('links')); ?>/img/banner/06.png" alt="ebusi" style="width: 300px;">
      </div>
      <div class="col-lg-5 col-md-12 ml-auto mr-auto md-mt-5">
        <div class="login-form text-center">
           <!---changes-->
        <img class="img-center mb-5" src="../images/ebusi-logo.svg" alt="">
        <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
          
            <?php else: ?>
          <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
		  <div class="form-group has-feedback">
			<input type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" data-error="Username is required." name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
			<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

		  <div class="form-group has-feedback">
			<input type="password" name="password" required autocomplete="current-password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password"  data-error="password is required.">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          
            <div class="form-group mt-4 mb-5">
              <div class="remember-checkbox d-flex align-items-center justify-content-between">
                <div class="checkbox">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="remember">
                        <?php echo e(__('Remember Me')); ?>

                    </label>
                </div>
               
                
              </div>
            </div> 
            <button type="submit" name="submit" class="btn btn-theme btn-block btn-circle" data-text="Sign in">
                <span>S</span><span>i</span><span>g</span><span>n</span><span> </span><span>I</span><span>n</span>
            </button>
          </form>
        
        
          <?php endif; ?>
        <?php endif; ?>

          
          <!--div class="social-icons fullwidth social-colored mt-4 text-center clearfix">
            <ul class="list-inline">
              <li class="social-facebook"><a href="#">Facebook</a>
              </li>
              <li class="social-twitter"><a href="#">Twitter</a>
              </li>
              <li class="social-gplus"><a href="#">Google Plus</a>
              </li>
            </ul>
          </div-->
        </div>
      </div>
    </div>
  </div>
</section>

<!--login end-->

</div>

<!--body content end--> 




<!--footer start-->

<footer class="footer dark-bg pos-r animatedBackground" data-bg-img="https://ebusi.rdnetworkbd.com/images/pattern/03.png">  
  <div class="footer-wave" data-bg-img="https://ebusi.rdnetworkbd.com/images/bg/08.png">
  </div>


  <div class="secondary-footer">
    <div class="container">
      <div class="copyright">
        <div class="row align-items-center">
          <div class="col-lg-6 col-md-12"> <span>© 2020 EBUSi a product of <a href="https://rdnetworkbd.com">RD NETWORK BD</a></span>
          </div>
          <div class="col-lg-6 col-md-12 text-lg-right md-mt-3">
            <div class="footer-social">
              <ul class="list-inline">
                <li class="mr-2"><a href="https://www.facebook.com/rdnetworkbd/"><i class="fab fa-facebook-f"></i> Facebook</a>
                </li>
                <li class="mr-2"><a href="https://twitter.com/rdnbd"><i class="fab fa-twitter"></i> Twitter</a>
                </li>
                <li><a href="#"><i class="fab fa-youtube"></i> YouTube</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--footer end-->


</div>




<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="flaticon-go-up-in-web"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="https://ebusi.rdnetworkbd.com/js/jquery.min.js"></script>
<!--== popper -->
<script src="https://ebusi.rdnetworkbd.com/js/popper.min.js"></script>
<!--== bootstrap -->
<script src="https://ebusi.rdnetworkbd.com/js/bootstrap.min.js"></script>
<!--== appear -->
<script src="https://ebusi.rdnetworkbd.com/js/jquery.appear.js"></script> 
<!--== modernizr -->
<script src="https://ebusi.rdnetworkbd.com/js/modernizr.js"></script> 
<!--== easing -->
<script src="https://ebusi.rdnetworkbd.com/js/jquery.easing.min.js"></script> 
<!--== menu --> 
<script src="https://ebusi.rdnetworkbd.com/js/menu/jquery.smartmenus.js"></script>
<!--== owl-carousel -->
<script src="https://ebusi.rdnetworkbd.com/js/owl-carousel/owl.carousel.min.js"></script> 
<!--== magnific-popup --> 
<script src="https://ebusi.rdnetworkbd.com/js/magnific-popup/jquery.magnific-popup.min.js"></script>
<!--== counter -->
<script src="https://ebusi.rdnetworkbd.com/js/counter/counter.js"></script> 
<!--== countdown -->
<script src="https://ebusi.rdnetworkbd.com/js/countdown/jquery.countdown.min.js"></script> 
<!--== canvas -->
<script src="https://ebusi.rdnetworkbd.com/js/canvas.js"></script>
<!--== confetti -->
<script src="https://ebusi.rdnetworkbd.com/js/confetti.js"></script>
<!--== step animation -->
<script src="https://ebusi.rdnetworkbd.com/js/snap.svg.js"></script>
<script src="https://ebusi.rdnetworkbd.com/js/step.js"></script>
<!--== contact-form -->
<script src="https://ebusi.rdnetworkbd.com/js/contact-form/contact-form.js"></script>
<!--== wow -->
<script src="https://ebusi.rdnetworkbd.com/js/wow.min.js"></script>
<!--== color-customize -->
<script src="https://ebusi.rdnetworkbd.com/js/color-customize/color-customizer.js"></script> 
<!--== theme-script -->
<script src="https://ebusi.rdnetworkbd.com/js/theme-script.js"></script>
<!-- inject js end -->

</body>


</html>

<?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/auth/register.blade.php ENDPATH**/ ?>