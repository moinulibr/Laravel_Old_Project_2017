<?php $__env->startSection('content'); ?>
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!---#############################################-->
<!--- push some things from here--->
    <!----for title---->
    <?php $__env->startPush('title'); ?>
    Income / Expense Edit
    <?php $__env->stopPush(); ?>
    <!----for title---->
<!--@@@@@@@@@@@@@-->
<!----custom css link here----->
   <?php $__env->startPush('css'); ?>
    <!-- Full Calender CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/fullcalendar.min.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/animate.min.css">
   <!-- Select 2 CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/select2.min.css">
   <!-- Date Picker CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/datepicker.min.css">
   <!-- Data Table CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/jquery.dataTables.min.css">
   <!-- SummerNote CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/summernote-bs4.html">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('links')); ?>/css/invoice.css">      
   <?php $__env->stopPush(); ?>
<!----custom css link here----->
<!--@@@@@@@@@@@@@-->
<!--- push some things from here--->
<!---#############################################-->


<!---#############################################-->
<!-- Breadcubs Area Start Here -->
    <!------top page ,page identify------->
    <?php $__env->startSection('page_identify'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-4">
            <h3>Income / Expense Edit</h3>
        </div>
        <div class="col-sm-12 col-md-8">
            <div style="float:right">
                <ul>
                    <li>Income / Expense</li>
                    <?php if(check_menu_button('expenses','view')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-expense.index')); ?>">Back</a>
                    </li>
                    <?php endif; ?>
                    <?php if(check_menu_button('expenses','create')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.transaction-expense.create')); ?>">Create</a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <!------top page ,page identify------->
    <!-- Breadcubs Area End Here -->
<!---#############################################-->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
  



<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>



<!--===================================================================================================================================================-->
<!--#*********************************************************Start Page content here*****************************************************************#-->  
<!--===================================================================================================================================================-->
<!-- page content  Start Here -->

     <!-- Add Expense Area Start Here -->
     <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Edit Income / Expense</h5>
                </div>
            </div>
            <form action="<?php echo e(route('admin.transaction-expense.update',$final_expense->id)); ?>" method="POST" class="new-added-form ">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <div class="row">
                     <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Category Type</label>
                        <select  name="category_type" id="category_type" class="form-control select2" >
                            <option value="">Select One</option>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($final_expense->category_type == $item->category_type ?'selected' :""); ?> value="<?php echo e($item->category_type); ?>"><?php echo e(ucfirst($item->category_type)); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php if($errors->has('category_type')): ?>
                        <span >
                        <strong style="color:red;"><?php echo e($errors->first('category_type')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group" id="category_details_div_selected" style="display:none;">
                        <label>Income / Expense Category </label>
                        <select name="" id="clickForHide" class="form-control">
                            <option value="<?php echo e($final_expense->expense_category_id); ?>"><?php echo e($final_expense->categories->name); ?></option>
                        </select>
                    </div>

                    <div class="col-xl-3 col-lg-6 col-12 form-group" id="category_details_div" style="display:none;">
                        <label>Income / Expense Category </label>
                        <select  name="expense_category_id" id="category_details" class="select2 form-control payment_method_option">
                            <option >Select One</option> 
                        </select>
                        <?php if($errors->has('expense_category_id')): ?>
                        <span >
                        <strong style="color:red;"><?php echo e($errors->first('expense_category_id')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Reference</label>
                        <input type="text" value="<?php echo e($order_id); ?>"  class="form-control" readonly>
                        <input name="reference_no" type="hidden"  value="<?php echo e($order_id); ?>" class="form-control"> 
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12 form-group">
                        <label>Date</label>
                        <input name="expense_date" required value="<?php echo e(date('d-m-Y',strtotime($final_expense->expense_date)) ?? old('expense_date')); ?>" type="text" placeholder="dd/mm/yy" class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                        <?php if($errors->has('expense_date')): ?>
                        <span >
                        <strong style="color:red;"><?php echo e($errors->first('expense_date')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>


                    <div class="table-responsive">
                        <table class="table display  text-nowrap" id="item_table">
                            <thead>
                                <tr>
                                    <th><label class="form-check-label">ID</label></th>
                                    <th style="width:25%;">Expense Title</th>
                                    <th style="width:35%;">Short Description</th>
                                    <th style="width:13%;">Total</th>
                                    <th style="width:12%;">Date</th>
                                    <th style="width:12%;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $details_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><label class="form-check-label">#<?php echo e($loop->index +1); ?></label></td>
                                    <td>
                                        <input value="<?php echo e($item->expense_title); ?>" name="expense_title[]" autocomplete="off"  style="width:100%;" type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control" style="width:100%;">
                                    </td>
                                    <td>
                                        <input value="<?php echo e($item->description); ?>" name="description[]" autocomplete="off"  style="width:100%;" type="text" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control">
                                    </td>
                                    <td>
                                        <input value="<?php echo e($item->final_total); ?>" name="final_total[]" autocomplete="off"  type="text" value="0" placeholder="" class="col-xl-8 col-lg-8 col-12 form-control finalTotal">
                                    </td>
                                    <td style="width:12%;">
                                        <input value="<?php echo e(date('d-m-Y',strtotime($item->expense_created_date))); ?>" name="expense_created_date[]"  autocomplete="off" type="text" placeholder="dd/mm/yy" style="width:80%;" class=" air-datepicker" data-position="bottom right">
                                    </td>
                                    <td>
                                        <button type="button" name="add" class="btn btn-success btn-sm add"><i class='fas fa-plus text-orange-green'></i></button>
                                        <button type="button" name="add" class="btn btn-danger btn-sm remove"><i style="color:yellow;" class="fas fa-times text-orange-red"></i></button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" style="text-align: right">Total Amount </td>
                                    <td colspan="3"  style="text-align: left">
                                        <strong id="showTotal"></strong>
                                        <input type="hidden" name="final_total_for_final_expense" id="showTotalVal">
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <?php if(check_menu_button('expenses','update')): ?>
                    <div class="form-group col-12 mg-t-8">
                        <button type="submit" id="submit" style="display:none;" class=" btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Update</button>
                    </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    <!-- Add Expense Area End Here -->

 <!-- page content  End Here -->
 <!--===================================================================================================================================================-->
<!--#*********************************************************End Page content here*****************************************************************#-->
<!--===================================================================================================================================================-->









<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<!--- push some things from here--->
<!----custom js link here----->
<?php $__env->startPush('js'); ?>


<script>
    $(document).ready(function(){
     
     $(document).on('click', '.add', function(){
        let count = 1;
        count = count + $('#item_table >tbody >tr').length;
        if(count <= 100)
        {
            let html = '';
            html += '<tr>';
            html += '<td>'+"#"+count  +'</td>';
            html += '<td><input autocomplete="off"  type="text" name="expense_title[]" class="form-control" /></td>';
            html += '<td><input autocomplete="off"  type="text" name="description[]" class="form-control" /></td>';
            html += '<td><input autocomplete="off"  type="text" name="final_total[]" value="0" style="width:69%;" class="form-control finalTotal" /></td>';
            html += '<td><input autocomplete="off"  type="text" name="expense_created_date[]" placeholder="dd/mm/yy" style="width:80%;" class=" air-datepicker" data-position="bottom right"></td>';
            //html += '<td><select name="item_unit[]" class="form-control item_unit"><option value="">Select Unit</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td>';
            html += '<td><button type="button" name="add" class="btn btn-success btn-sm add" style="margin-right:1%;"><i class="fas fa-plus text-orange-green"></i></button><button type="button"  name="remove" class="btn btn-danger btn-sm remove"><i style="color:yellow;" class="fas fa-times text-orange-red"></i></button></td></tr>';
            $('#item_table').append(html);
        }
     });
     
     $(document).on('click', '.remove', function(){
      $(this).closest('tr').remove();

        let total = 0;
        $('.finalTotal').each(function() 
        {
            total += parseFloat($(this).val());
        })
        $('#showTotal').text(total);
        $('#showTotalVal').val(total);
     });
     

    $(document).on('keyup','.finalTotal',function(){
        let total = 0;
        $('.finalTotal').each(function() 
        {
            total += parseFloat($(this).val());
        })
        $('#showTotal').text(total);
        $('#showTotalVal').val(total);

        if(total > 0)
        {
            $('#submit').show();
        }
        else{
            $('#submit').hide();
        }
    });
    let total = 0;
    $('.finalTotal').each(function() 
    {
        total += parseFloat($(this).val());
    })
    $('#showTotal').text(total);
    $('#showTotalVal').val(total);

    if(total > 0)
    {
        $('#submit').show();
    }
    else{
        $('#submit').hide();
    }

     /*
        $('#insert_form').on('submit', function(event){
        event.preventDefault();
        var error = '';
        $('.item_name').each(function(){
        var count = 1;
        if($(this).val() == '')
        {
            error += "<p>Enter Item Name at "+count+" Row</p>";
            return false;
        }
        count = count + 1;
        });
        
        $('.item_quantity').each(function(){
        var count = 1;
        if($(this).val() == '')
        {
            error += "<p>Enter Item Quantity at "+count+" Row</p>";
            return false;
        }
        count = count + 1;
        });
        
        $('.item_unit').each(function(){
        var count = 1;
        if($(this).val() == '')
        {
            error += "<p>Select Unit at "+count+" Row</p>";
            return false;
        }
        count = count + 1;
        });
        var form_data = $(this).serialize();
        if(error == '')
        {
        $.ajax({
            url:"insert.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
            if(data == 'ok')
            {
            $('#item_table').find("tr:gt(0)").remove();
            $('#error').html('<div class="alert alert-success">Item Details Saved</div>');
            }
            }
        });
        }
        else
        {
        $('#error').html('<div class="alert alert-danger">'+error+'</div>');
        }
        });
     */

    });
    </script>


    <div id="category_type_url" data-url="<?php echo e(route('admin.transaction_category_type')); ?>"></div>

<script>
    $(document).ready(function(){

        $('#category_type').on('change',function(e){
            e.preventDefault();
           let url = $('#category_type_url').data('url'); 
           let category_type = $(this).val();
            $.ajax({
                url:url,
                datatype:'html',
                data:{category_type:category_type},
                success:function(response)
                {   
                   $('#category_details').html(response);
                   if(response !="")
                   {
                    $('#category_details_div').show(100);
                    $('#category_details_div_selected').hide();
                   }
                   else{
                    $('#category_details_div').hide(100);
                    $('#category_details_div_selected').hide();
                   }
                },
            });
        });
        /*-- On change function is end here---*/


        /*--Default is working here--*/
        let category_type = $('select#category_type option:selected').val();
        let url = $('#category_type_url').data('url'); 
            $.ajax({
                url:url,
                datatype:'html',
                data:{category_type:category_type},
                success:function(response)
                {   
                   $('#category_details').html(response);
                   if(response !="")
                   {
                    $('#category_details_div_selected').show(100);
                    $('#clickForHide').attr('name','expense_category_id');
                    $('#category_details').removeAttr('name');
                   }
                   else{
                    $('#category_details_div_selected').hide(100);
                    $('#category_details').removeAttr('name');
                   }
                },
            });
        /*--Default is working  End here--*/

            $('#clickForHide').click(function(){
                $('#category_details_div_selected').hide();
                $('#clickForHide').removeAttr('name');
                $('#category_details_div').show();
                $('#category_details').attr('name','expense_category_id');
            });

    });
</script>




    <script>
    /*
        $(document).ready(function(){
            $('.addMore').click(function(){
                let lineNo = "djfk";
                markup = "<tr><td>This is row "  
                    + lineNo + "</td></tr>"; 
                tableBody = $("table tbody"); 
                tableBody.prepend(markup); 
                lineNo++; 
            });
         
            $(".add-row").click(function() {
                let count = 1;                                                                                                                                                                                                                                                                                                                                                                    
                var markup = "<tr><td>"+count+"</td><td><input name='expense_title[]' type='text' /></td><td><input name='discription[]' type='text' /></td><input name='expense_title[]' type='text' /></td><td><input name='final_total[]' type='text' /></td><td><input type='text' placeholder='dd/mm/yy'  class='air-datepicker' data-position='bottom right'></td><td><div class='row'><div class='col-xl-6 col-lg-6 col-12'><a class='dropdown-item addMore add-row' href='#' ><i class='fas fa-plus text-orange-green'></i></a></div><div class='col-xl-6 col-lg-6 col-12'><a href='#' class='dropdown-item delete-row'><i class='fas fa-times text-orange-red'></i></a></div></div></td></tr>";
                $("table tbody").append(markup); 
                //$('#myTable > tbody:last-child').append(markup);
                count =  count +1;                                                                                                                                                                                                                                                                                                                       
            });
            /* Find and remove selected table rows */
            /*
            $(document).on("click",".delete-row",function() {
                $("table tbody").find('input[name="record"]').each(function() {
                    if ($(this).is(":checked")) {
                        $(this).parents("tr").remove();
                    }
                });
            });

        });
    */
    </script>

 <?php $__env->stopPush(); ?>
<!----custom js link here----->
<!--- push some things from here--->
<!--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\working\runningproject\laravel\Rajon_Vai\project_new\resources\views/backend/admin/transaction/expense/edit.blade.php ENDPATH**/ ?>