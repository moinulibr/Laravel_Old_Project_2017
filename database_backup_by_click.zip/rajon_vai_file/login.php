<?php

$servername = "localhost";
$username = "rajon_digiedu";
$password = "rajon@digiedu";
$dbname = "rajon_digiedu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


if (!empty($_POST['user']) && !empty($_POST['pass']))
	{
		//echo 'thik ache';
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		
		$sql = "SELECT * FROM user WHERE user = '".$user."' AND pass = '".$pass."'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			while($u = $result->fetch_object()) {
				/*echo $u->user"<br>" .$u->pass;
				
				or
				echo $u->user;
				echo "<br>";
				echo $u->pass;*/
				
				$user = $u->user;
				$pass = $u->pass;
			}
			session_start();
			$_SESSION["user"] = $user;
			header('Location: /login/dashboard/index.php');
			//echo "dhuklam";
			// output data of each row
			/*while($row = $result->fetch_assoc()) {
				echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
			}*/
		} else {
			echo "Username or Password is not match!! ";
			header('Location: index.php');
		}
	}
	else {
		header('Location: index.php');
	}

?>