
		
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
            <div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
               <div class="mobile-sidebar-header d-md-none">
                    <div class="header-logo">
                        <a href="/dashboard"><img src="/login/img/ebusi-logo.png" alt="logo"></a>
                    </div>
               </div>
                <div class="sidebar-menu-content">
                    <ul class="nav nav-sidebar-menu sidebar-toggle-view" id="submenu_toggle">
                        <li class="nav-item">
                            <a href="/login/dashboard/index.php" class="nav-link"><i class="flaticon-dashboard"></i><span>Dashboard</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="/login/accounts/index.php" class="nav-link"><i class="fas fa-landmark"></i><span>Accounts</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="/login/clients/index.php" class="nav-link"><i class="fas fa-street-view"></i><span>Clients</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="/login/supplier/index.php" class="nav-link"><i class="fas fa-truck-moving"></i><span>Suppliers</span></a>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="fas fa-shopping-basket"></i><span>Products</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/products/index.php" class="nav-link"><i class="fas fa-angle-right"></i>All Products</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/products/categories.php" class="nav-link"><i class="fas fa-angle-right"></i>Products Categories</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>Transactions</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/transactions/sales/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Sales</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/transactions/expense/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Expense</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/transactions/purchases/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Purchases</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/transactions/categories.php" class="nav-link"><i class="fas fa-angle-right"></i>Categories</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="flaticon-multiple-users-silhouette"></i><span>User</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/users/employee/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Employee</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/users/admin.php" class="nav-link"><i class="fas fa-angle-right"></i>Admin</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/users/manage-role.php" class="nav-link"><i class="fas fa-angle-right"></i>Manage Role</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="/login/settings.php" class="nav-link"><i class="flaticon-settings"></i><span>Settings</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="/login/add-ons.php" class="nav-link"><i class="fas fa-dice"></i><span>Add-ons</span></a>
                        </li>
                        
                        <!--li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>Invoice & Billing</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Dashboard</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a href="/login/accounting/add-invoice.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Invoice</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/accounting/all-invoice.php" class="nav-link"><i class="fas fa-angle-right"></i>All Invoice</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Clients</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/index.php" class="nav-link"><i class="fas fa-angle-right"></i>All Clients</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/accounting/add-income-expense.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Income/Expense</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/accounting/all-income-expense.php" class="nav-link"><i class="fas fa-angle-right"></i>All Income/Expense</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Accounts</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/index.php" class="nav-link"><i class="fas fa-angle-right"></i>All Accounts</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Settings</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>HR & Payroll</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Dashboard</a>
                                </li>
                                
                                <!-- HR Start->
                                <li class="nav-item">
                                    <a href="/login/accounting/add-invoice.php" class="nav-link"><i class="fas fa-angle-right"></i>Company </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/accounting/all-income-expense.php" class="nav-link"><i class="fas fa-angle-right"></i>Department</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Designation</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Employee</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/index.php" class="nav-link"><i class="fas fa-angle-right"></i>All Employee</a>
                                </li>
                                <!-- HR End-->
                                
                                <!-- Payroll Start->
                                <li class="nav-item">
                                    <a href="/login/clients/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Employee Attendance/Leave</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Employee Performance</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/accounting/add-income-expense.php" class="nav-link"><i class="fas fa-angle-right"></i>Salary</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/index.php" class="nav-link"><i class="fas fa-angle-right"></i>Reports</a>
                                </li>
                                <!-- Payroll End->
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Settings</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="fas fa-file-invoice-dollar"></i><span>Accounting & Inventory</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Dashboard</a>
                                </li>
                                
                                <!-- Inventory Start->
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Products</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Products Categories</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Stock Central</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Purchase Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Purchase Invoice</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Inbound Stock</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Suppliers</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Inventory Logs</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Customers</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Sales Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Sales Invoice</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Salesman</a>
                                </li>
                                <!-- Inventory End-->
                                
                                <!-- Accounting Start->
                                <li class="nav-item">
                                    <a href="/login/account/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Add Accounts</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/index.php" class="nav-link"><i class="fas fa-angle-right"></i>All Accounts</a>
                                </li>
                                <li class="nav-item">
                                    <a href="/login/account/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Transaction Report</a>
                                </li>
                                <!-- Accounting End->
                                <li class="nav-item">
                                    <a href="/login/clients/add.php" class="nav-link"><i class="fas fa-angle-right"></i>Settings</a>
                                </li>
                            </ul>
                        </li-->
                        
                        
                    </ul>
                </div>
            </div>
            <!-- Sidebar Area End Here -->
            
            
            
           
            
            
            
            
            