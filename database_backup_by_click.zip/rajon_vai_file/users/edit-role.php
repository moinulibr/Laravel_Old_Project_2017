<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Users</a>
                        </li>
                        <li>Edit User Role</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <form class="new-added-form form-inline">
                            <div class="row">
                                <div class="col-6">
                                <div class="card height-auto mg-t-30">
                                    <div class="heading-layout1">
                                        <div class="item-title">
                                            <h5>Edit Role</h5>
                                        </div>
                                    </div>
                                        <form class="new-added-form form-inline">
                                                <div class="row">
                                                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                                                        <label class="col-xl-4 col-lg-4 col-12">Role Name:</label>
                                                        <input type="text" placeholder="Admin" class="col-xl-8 col-lg-8 col-12 form-control">
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                                                        <label class="col-xl-4 col-lg-4 col-12">Manage Account :</label>
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input">
                                                            <label class="form-check-label"></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-12 form-group">
                                                        <label class="col-xl-4 col-lg-4 col-12">View Account :</label>
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input">
                                                            <label class="form-check-label"></label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-12 mg-t-8">
                                                        <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Save Change</button>
                                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card height-auto mg-t-30">
                                    <div class="heading-layout1">
                                        <div class="item-title">
                                            <h5>View Category</h5>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table display data-table text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input checkAll">
                                                            <label class="form-check-label">ID</label>
                                                        </div>
                                                    </th>
                                                    <th>Role Name</th>
                                                    <th>Capability</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input">
                                                            <label class="form-check-label">#1</label>
                                                        </div>
                                                    </td>
                                                    <td>Admin</td>
                                                    <td>Manage Account</td>
                                                    <td>
                                                       <div class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                               <span class="flaticon-more-button-of-three-dots"></span>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <a class="dropdown-item" href="/login/users/edit-role.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                                <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input">
                                                            <label class="form-check-label">#2</label>
                                                        </div>
                                                    </td>
                                                    <td>Employee</td>
                                                    <td>View Account </td>
                                                    <td>
                                                       <div class="dropdown">
                                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                               <span class="flaticon-more-button-of-three-dots"></span>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <a class="dropdown-item" href="/login/users/edit-role.php"><i class="fas fa-edit text-orange-peel"></i>Edit</a>
                                                                <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Delete</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!---Table responsive end here ---->
                                </div>
                            </div><!--col-->
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->

<?php include '../footer.php';?>