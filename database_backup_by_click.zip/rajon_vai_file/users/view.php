<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <ul>
            <li>
                <a href="../dashboard/index.php">Home</a>
            </li>
            <li>User Details</li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>About User</h3>
                </div>
            </div>
            <div class="single-info-details">
                <div class="item-img">
                    <img src="../img/figure/student1.jpg" alt="student">
                </div>
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium">-</h3>
                        <div class="header-elements">
                            <ul>
                                <li><a href="#"><i class="far fa-edit"></i></a></li>
                                <li><a href="#"><i class="fas fa-print"></i></a></li>
                                <li><a href="#"><i class="fas fa-download"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="info-table table-responsive">
                        <table class="table text-nowrap">
                            <tbody>
                                <tr>
                                    <td>Clients Name:</td>
                                    <td class="font-medium text-dark-medium">Jamal Uddin</td>
                                </tr>
                                <tr>
                                    <td>Clients Gender:</td>
                                    <td class="font-medium text-dark-medium">Male</td>
                                </tr>
                                <tr>
                                    <td>Phone Number:</td>
                                    <td class="font-medium text-dark-medium">0154875201 </td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td class="font-medium text-dark-medium">jamal@email.com </td>
                                </tr>
                                <tr>
                                    <td>Blood Group:</td>
                                    <td class="font-medium text-dark-medium">O+</td>
                                </tr>
                                <tr>
                                    <td>Religion:</td>
                                    <td class="font-medium text-dark-medium">Islam</td>
                                </tr>
                                <tr>
                                    <td>Clients Address:</td>
                                    <td class="font-medium text-dark-medium">270/ka, jamal pur</td>
                                </tr>
                                <tr>
                                    <td>ID No:</td>
                                    <td class="font-medium text-dark-medium">12546987TXT</td>
                                </tr>
                                <tr>
                                    <td>Departments:</td>
                                    <td class="font-medium text-dark-medium">Admin</td>
                                </tr>
                                <tr>
                                    <td>Designation:</td>
                                    <td class="font-medium text-dark-medium">Managing Director</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Student Details Area End Here -->

<?php include '../footer.php';?>