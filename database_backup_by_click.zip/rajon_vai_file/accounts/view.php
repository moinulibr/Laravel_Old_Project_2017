<?php include '../session.php';?>
<?php include '../header.php';?>
<?php include '../topbar.php';?>
<?php include '../sidebar.php';?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <ul>
            <li>
                <a href="../dashboard/index.php">Home</a>
            </li>
            <li>Account Details</li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Account Details</h5>
                </div>
            </div>
            <div class="single-info-details">
                <!--div class="item-img">
                    <img src="../img/figure/student1.jpg" alt="student">
                </div-->
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium">-</h3>
                        <div class="header-elements">
                            <ul>
                                <li><a href="#"><i class="far fa-edit"></i></a></li>
                                <li><a href="#"><i class="fas fa-print"></i></a></li>
                                <li><a href="#"><i class="fas fa-download"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!--p>Aliquam erat volutpat. Curabiene natis massa sedde lacu stiquen sodale 
               word moun taiery.Aliquam erat volutpaturabiene natis massa sedde  sodale 
               word moun taiery.
            </p-->
                    <div class="info-table table-responsive">
                        <table class="table text-nowrap">
                            <tbody>
                                <tr>
                                    <td>Account Type :</td>
                                    <td class="font-medium text-dark-medium">Bank Account</td>
                                </tr>
                                <tr>
                                    <td>Account Name:</td>
                                    <td class="font-medium text-dark-medium">M/S MARUF ENTERPRISE</td>
                                </tr>
                                <tr>
                                    <tr>
                                        <td>Account No :</td>
                                        <td class="font-medium text-dark-medium">0761330004411</td>
                                    </tr>
                                    <td>Company Name :</td>
                                    <td class="font-medium text-dark-medium">Social Islami Bank</td>
                                </tr>
                                <tr>
                                    <td>Company Address :</td>
                                    <td class="font-medium text-dark-medium">Alongkar Mor </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card height-auto mg-t-30">
                <div class="heading-layout1">
                    <div class="item-title">
                        <h5>Transaction Details</h5>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table display data-table text-nowrap">
                        <thead>
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input checkAll">
                                        <label class="form-check-label">ID</label>
                                    </div>
                                </th>
                                <th>Invoice No.</th>
                                <th>Date</th>
                                <th>Pay to/Receive from</th>
                                <th>Amount in</th>
                                <th>Amount out</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#1</label>
                                    </div>
                                </td>
                                <td>125487</td>
                                <td>02/10/2019</td>
                                <td>SIMEX Bangladesh</td>
                                <td>৳100.00</td>
                                <td>৳0.00</td>
                                <td>Income</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#2</label>
                                    </div>
                                </td>
                                <td>120487</td>
                                <td>02/10/2019</td>
                                <td>Shipping Yeard</td>
                                <td>৳0.00</td>
                                <td>৳50.00</td>
                                <td>Expenses</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input">
                                        <label class="form-check-label">#3</label>
                                    </div>
                                </td>
                                <td>120487</td>
                                <td>02/10/2019</td>
                                <td>Employee</td>
                                <td>৳0.00</td>
                                <td>৳50.00</td>
                                <td>Expenses</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Total sum</td>
                                <td>৳100</td>
                                <td>৳50</td>
                                <td>৳50</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!---Table responsive end here ---->
            </div>
        </div>
        <!---card body ---->
    </div>
    <!-- Student Details Area End Here -->  

<?php include '../footer.php';?>