<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>EBUSi | Business Management ERP</title>
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        /*=============== Page: Login & Register =================*/
        
        body {
            background: #283891;
            background-image: #999;
        }
        
        .login-logo img {
            width: 150px;
        }
        
        .login-logo,
        .register-logo {
            font-size: 35px;
            text-align: center;
            margin-bottom: 25px;
            font-weight: 300;
        }
        
        .login-logo a,
        .register-logo a {
            color: #444;
        }
        
        .login-page,
        .register-page {
            background: #d2d6de;
        }
        
        .login-box,
        .register-box {
            width: 360px;
            margin: 7% auto;
        }
        
        @media (max-width: 768px) {
            .login-box,
            .register-box {
                width: 90%;
                margin: 20% auto;
            }
        }
        
        .login-box-body,
        .register-box-body {
            background: #fff;
            padding: 20px;
            border-top: 0;
            color: #666;
            border: 1px solid #ccc;
        }
        
        .login-box-body .form-control-feedback,
        .register-box-body .form-control-feedback {
            color: #777;
        }
        
        .login-box-msg,
        .register-box-msg {
            margin: 0;
            text-align: center;
            padding: 0 20px 20px 20px;
        }
        
        .social-auth-links {
            margin: 10px 0;
        }
        
        .col-xs-8 {
            width: 66.66666667%;
            float: left;
            position: relative;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px;
        }
        
        input[type=checkbox],
        input[type=radio] {
            box-sizing: border-box;
            position: absolute;
            top: 15%;
            left: -20%;
            display: block;
            width: 50%;
            height: 70%;
            margin: 0px;
            padding: 0px;
            background: #999 !important;
            border: 0px;
        }
        
        .icheck > label {
            padding-left: 0;
        }
        
        .checkbox label,
        .radio label {
            min-height: 25px;
            padding-left: 25px;
            margin-bottom: 0;
            font-weight: 400;
            cursor: pointer;
        }
        
        .checkbox,
        .radio {
            position: relative;
            display: block;
            margin-top: 10px;
            margin-bottom: 10px;
        }
        
        .col-xs-4 {
            width: 33.33333333%;
            float: left;
            position: relative;
            min-height: 1px;
            padding-right: 15px;
        }
        
        .btn.btn-flat {-
            -webkit-box-shadow: none;
            -moz-box-shadow: none;
            box-shadow: none;
            border-width: 1px;
        }
        
        .btn-primary {
            background-color: #283891;
            border-color: #283891;
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
        
        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            font-weight: 400;
            line-height: 1.42857143;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-image: none;
            -border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .btn-social >:first-child {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 35px;
            line-height: 34px;
            font-size: 1.4em;
            text-align: center;
            border-right: 1px solid rgba(0, 0, 0, 0.2);
        }
        
        .fa {
            display: inline-block;
            font: normal normal normal 14px/1 FontAwesome;
            font-size: inherit;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .btn-facebook {
            color: #ffffff;
            background-color: #3b5998;
            border-color: rgba(0, 0, 0, 0.2);
        }
        
        .btn-facebook:hover {
            color: #ffffff;
            background-color: #2b4273;
            border-color: rgba(0, 0, 0, 0.2);
        }
        
        .btn-social {
            position: relative;
            padding-left: 44px;
            text-align: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .btn-block+.btn-block {
            margin-top: 5px;
        }
        
        .btn-google {
            color: #ffffff;
            background-color: #dd4b39;
            border-color: rgba(0, 0, 0, 0.2);
        }
        
        .btn-google:hover {
            color: #ffffff;
            background-color: #b33c2d;
            border-color: rgba(0, 0, 0, 0.2);
        }
        /*=============== Login END =================*/
    </style>

</head>

<body>
    <div class="login-box">
        <!--div class="login-logo">
		<a href="dashboard.php">digi<b>EDU</b></a>
	  </div-->
        <!-- /.login-logo -->
        <div class="login-box-body">
            <div class="login-logo">
                <a href="index.php">
                    <img src="img/ebusi-logo.png" alt="logo">
                </a>
            </div>
            <p class="login-box-msg">Sign in to start your session</p>

            <form action="login.php" method="post">
                <div class="form-group has-feedback">
                    <input type="text" name="user" class="form-control" placeholder="User">
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" name="pass" class="form-control" placeholder="Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-8">
                        <div class="checkbox icheck">
                            <label>
                                <input type="checkbox"> Remember Me
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" name="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <!--div class="social-auth-links text-center">
		  <p>- OR -</p>
		  <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using
			Facebook</a>
		  <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
			Google+</a>
		</div>
		<!-- /.social-auth-links -->

            <a href="#">I forgot my password</a>
            <br>
            <a href="register.html" class="text-center">Register a new membership</a>

        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->
    </div>
    <!-- /.login-box-background -->

    <!-- page script -->
    <script>
        $(function() {
            $('input').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
                increaseArea: '20%' // optional
            });
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>

</html>