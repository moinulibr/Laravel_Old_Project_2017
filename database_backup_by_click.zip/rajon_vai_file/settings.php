<?php include './session.php';?>
<?php include './header.php';?>
<?php include './topbar.php';?>
<?php include './sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Settings</h3>
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Home</a>
                        </li>
                        <li>Settings</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Tab Area Start Here -->
                <div class="card ui-tab-card">
                    <div class="card-body">
                        <div class="heading-layout1 mg-b-25">
                            <div class="item-title">
                                <h3>Settings</h3>
                            </div>
                        </div>
                        <div class="basic-tab">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                  <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab" aria-selected="true">Basic Settings</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-selected="false">File Attachments</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" data-toggle="tab" href="#tab3" role="tab" aria-selected="false">Caterory Settings</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" data-toggle="tab" href="#tab4" role="tab" aria-selected="false">Tax Settings</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" data-toggle="tab" href="#tab5" role="tab" aria-selected="false">Graph Settings</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" data-toggle="tab" href="#tab6" role="tab" aria-selected="false">Tools</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="form-group col-xl-12 col-lg-12 col-12">
                                            <label class="col-xl-4 col-lg-4 col-12 ">Default Currency :</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">(৳) BDT</option>
                                                <option value="1">(৳) BDT</option>
                                                <option value="2">($) USD</option>
                                            </select>
                                            <p>This controls what currency is used for calculation.</p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Currency Position :</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">(৳ 99.99) BDT</option>
                                                <option value="1">(৳ 99.99) BDT</option>
                                                <option value="2">(99.99 ৳) BDT</option>
                                            </select>
                                            <p>This controls the position of the currency symbol.</p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Thousand Separator :</label>
                                            <input type="text" placeholder="," class="col-xl-8 col-lg-8 col-12 form-control">
                                            <p>This sets the thousand separator of displayed prices.</p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Decimal Separator :</label>
                                            <input type="text" placeholder="." class="col-xl-8 col-lg-8 col-12 form-control">
                                            <p>This sets the decimal separator of displayed prices.</p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Number of Decimals :</label>
                                            <input type="text" placeholder="2" class="col-xl-8 col-lg-8 col-12 form-control">
                                            <p>This sets the number of decimal points shown in displayed prices.</p>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="tab2" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Enable File Attachment :</label>
                                            <select  class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">Enable</option>
                                                <option value="1">Disabled</option>
                                            </select>
                                            <p>This will allow user to upload files to log.</p>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="tab3" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Category Color :</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">Yes, each category must have a unique color</option>
                                                <option value="1">No, each category no unique color</option>
                                            </select>
                                            <p>.</p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Income Default Category :</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">Choose Category</option>
                                                <option value="1">Cash Reacive</option>
                                            </select>
                                            <p>Choose default category for income log entry <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">edit</button></p>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Expense Default Category :</label>
                                            <select class="col-xl-8 col-lg-8 col-12 form-control">
                                                <option value="">Choose Category</option>
                                                <option value="1">Office expenses</option>
                                            </select>
                                            <p>Choose default category for expense log entry.</p>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="tab4" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Sales Tax (VAT) :</label>
                                            <input type="text" placeholder="0" class="col-xl-8 col-lg-8 col-12 form-control">
                                            <p>Default Tax(Vat) %</p>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="tab5" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Legend Color for Income :</label>
                                            <div>
                                                <input type="color" id="head" name="head" value="#5cc488">
                                                <label for="head"></label>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">Legend Color for Expense :</label>
                                            <div>
                                                <input type="color" id="head" name="head" value="#e66465">
                                                <label for="head"></label>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="tab6" role="tabpanel">
                                    <form class="form-inline">
                                        <div class="col-xl-12 col-lg-12 col-12 form-group">
                                            <label class="col-xl-4 col-lg-4 col-12">On Uninstall delete data</label>
        									<label for="exinc-type-2" class="radio-inline">
        									    <input type="radio" class="exinc-type" id="exinc-type-1" name="exinc-type" value="1" required="" checked="checked">Yes
        									    <input type="radio" class="exinc-type" id="exinc-type-2" name="exinc-type" value="2" required="">No
        									</label>
        									<p>Default Tax(Vat) %</p>
                                        </div>
                                    </form>
                                    <div class="col-12 form-group mg-t-8">
                                        <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save Changes</button>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>

<?php include './footer.php';?>
