<?php include '../../session.php';?>
<?php include '../../header.php';?>
<?php include '../../topbar.php';?>
<?php include '../../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Sales</a>
                        </li>
                        <li>Receive Payment</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Receive Payment</h5>
                            </div>
                        </div>
                        <form class="new-added-form ">
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Order No</label>
                                    <input type="text" placeholder="14953" class="form-control" disabled>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Receive From</label>
                                    <input type="text" placeholder="Shamim vai" class="form-control" disabled>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Payment Date</label>
                                    <input type="text" placeholder="dd/mm/yyyy" class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Payment Method</label>
                                    <select class="form-control select2">
                                        <option value="">None</option> 
                                        <option value="1">bKash Payment</option> 
                                        <option value="2">Cash Payment</option> 
                                        <option value="3">Bank Payment</option> 
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Deposit to</label>
                                    <select class="form-control select2">
                                        <option>None</option> 
                                        <option>Social Islami Bank</option> 
                                        <option>Social Islami Bank</option> 
                                        <option>Social Islami Bank</option> 
                                    </select>
                                </div>
                                
                                <div class="table-responsive">
                                    <table class="table display data-table text-nowrap">
                                        <thead>
                                            <tr>
                                                <th><label class="form-check-label">ID</label></th>
                                                <th>Product/Service</th>
                                                <th>Qty</th>
                                                <th>Unit Price</th>
                                                <th>Total Amount</th>
                                                <th>Paid Amount</th>
                                                <th>Due Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><label class="form-check-label">#1</label></td>
                                                <td>Angel-5*5mm</td>
                                                <td>10</td>
                                                <td>৳ 100.00</td>
                                                <td>৳ 1000.00</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td><label class="form-check-label">#2</label></td>
                                                <td>Scooter</td>
                                                <td>1</td>
                                                <td>৳ 70000.00</td>
                                                <td>৳ 70000.00</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr class="discount-rate-row">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>৳ 71000.00</td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td>৳ 71000.00</td>
                                                
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Add Payment</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->
                
               
<?php include '../../footer.php';?>