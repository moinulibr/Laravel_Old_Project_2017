<?php include '../../session.php';?>
<?php include '../../header.php';?>
<?php include '../../topbar.php';?>
<?php include '../../sidebar.php';?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <ul>
            <li>
                <a href="../dashboard/index.php">Purchases</a>
            </li>
            <li>Purchases Invoice Details</li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h5>Purchases Invoice Details</h5>
                </div>
            </div>
            <div class="single-info-details">
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium"></h3>
                        <div class="header-elements">
                            <ul>
                                <li><a href="#"><i class="far fa-edit"></i></a></li>
                                <li><a href="#"><i class="fas fa-print"></i></a></li>
                                <li><a href="#"><i class="fas fa-download"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="info-table table-responsive">
                        
                        
                        
                        <div class="order-branding">
                            <div class="right-invoice">INVOICE</div>
                            
                            <h2 class="company-address">SM Trading</h2>
                            <p>
                                P.C Road, Saraipara,</br>
                                Pahartali, Chittagong - 4217</br>
                                Mobile: 01728-817223</br>
                                Mobile: 01817-731181</br>
                                smtradingctg23@gmail.com
                            </p>
                        </div>
                        <div class="order-addresses">
                            <div class="billing-address">
                                <h3>Supplier:</h3>
                                <p>
                                P.C Road, Saraipara,</br>
                                Pahartali, Chittagong - 4217</br>
                                Mobile: 01728-817223</br>
                                Mobile: 01817-731181</br>
                                smtradingctg23@gmail.com
                            </p>
                            </div>
                            <div class="shipping-address">
                            </div>
                            
                            
                            <table class="order-info">
                                <tr>
                                    <th>Order Number:</th>
                                    <td>125487</td>
                                </tr>
                                <tr>
                                    <th>Order Date:</th>
                                    <td>26th February 2020</td>
                                </tr>
                                <tr>
                                    <th>Payment Status:</th>
                                    <td style="color:red">UNPAID</td>
                                </tr>
                            </table>
                        </div>
                        <table class="order-items">
                            <thead>
                                <tr>
                                    <th class="product">Product/Service</th>
                                    <th class="product">Description</th>
                                    <th class="qty">Qty</th>
                                    <th class="price">Unit Price</th>
                                    <th class="total">Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="product">Angle 150*150</td>
                                    <td class="product">puran mall</td>
                                    <td class="qty">100</td>
                                    <td class="price">৳ 1.00</td>
                                    <td class="total">৳ 100.00</td>
                                </tr>
                                <tr>
                                    <td class="product">Angle 150*150</td>
                                    <td class="product">notun mal</td>
                                    <td class="qty">100</td>
                                    <td class="price">৳ 1.00</td>
                                    <td class="total">৳ 100.00</td>
                                </tr>
                            </tbody>
                            <tfoot style="text-align: right;">
                                <tr class="order-discount">
                                    <th colspan="4">Fee:</th>
                                    <td colspan="1"></td>
                                </tr>
                                <!-- end order_discount -->
                                <tr class="order-total">
                                    <th colspan="4">Payable Amount:</th>
                                    <td colspan="1"></td>
                                </tr>
                                <tr class="pos_cash-tendered">
                                    <th colspan="4">Paid Amount:</th>
                                    <td colspan="1"></td>
                                </tr>
                                <tr class="pos_cash-change">
                                    <th colspan="4">Due Amount:</th>
                                    <td colspan="1"></td>
                                </tr>
                            </tfoot>
                        </table>
                        <!--h4>Terms & Conditions:</h4>
                        <p>
                            1. Please write a cheque under the name of SM Trading.
                        </p-->
                        <table class="signature">
                            <tr>
                                <td class="signature-left">
                                    Receiver's signature
                                </td>
                                <td class="signature-right">
                                    On behalf of SM Trading
                                </td>
                            </tr>
                        </table>
                        <div class="order-notes"></div>
                        <div class="footer">
                            <hr>
                            <p>If you have any inquiry about this, please feel free to contact
                                <br> Mr. Milon (01728 817223)
                                <br> Thank You For Your Business !!</p>
                        </div>
                        
                    </div><!-- Table Content -->
                </div>
            </div>
        </div>
        <!---card body ---->
    </div>
    <!-- Student Details Area End Here -->  

<?php include '../../footer.php';?>