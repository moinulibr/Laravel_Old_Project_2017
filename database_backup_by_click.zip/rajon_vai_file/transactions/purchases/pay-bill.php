<?php include '../../session.php';?>
<?php include '../../header.php';?>
<?php include '../../topbar.php';?>
<?php include '../../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Purchases</a>
                        </li>
                        <li>Purchases Bill Payment</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Add Expense Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>Purchases Bill Payment</h5>
                            </div>
                        </div>
                        <form class="new-added-form ">
                            <div class="row">
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Pay to</label>
                                    <select class="form-control select2">
                                        <option value="">Supplier</option>
                                        <option value="1">Desco</option>
                                        <option value="2">Tong Dokan</option>
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Reference</label>
                                    <input type="text" placeholder="2022" class="form-control">
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Payment Date</label>
                                    <input type="text" placeholder="dd/mm/yy" class="form-control air-datepicker" data-position="bottom right"><i class="far fa-calendar-alt"></i>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Payment Method:</label>
                                    <select class="form-control select2">
                                        <option value="">Bank Payment</option> 
                                        <option value="1">bKash Payment</option> 
                                        <option value="2">Cash Payment</option> 
                                        <option value="3">Bank Payment</option> 
                                    </select>
                                </div>
                                <div class="col-xl-3 col-lg-6 col-12 form-group">
                                    <label>Payment From:</label>
                                    <select class="form-control select2">
                                        <option value="">Social Islami Bank</option>
                                        <option value="1">Social Islami Bank</option>
                                        <option value="2">bKash</option>
                                    </select>
                                </div>
                                <div class="table-responsive">
                                    <table class="table display data-table text-nowrap">
                                        <thead>
                                            <tr>
                                                <th><label class="form-check-label">ID</label></th>
                                                <th>Product/Service</th>
                                                <th>Description</th>
                                                <th>Qty</th>
                                                <th>Unit Price</th>
                                                <th>Total Amount</th>
                                                <th>Paid Amount</th>
                                                <th>Due Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><label class="form-check-label">#1</label></td>
                                                <td>Angel 500mm</td>
                                                <td>puran mal</td>
                                                <td>100</td>
                                                <td>৳ 100.00</td>
                                                <td>৳ 1000.00</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td><label class="form-check-label">#2</label></td>
                                                <td>Steel Sheet paiap</td>
                                                <td>notun mal</td>
                                                <td>100</td>
                                                <td>৳ 10.00</td>
                                                <td>৳ 1000.00</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr class="discount-rate-row">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>৳ 70100.00</td>
                                                <td><input type="text" placeholder="৳ 0.00" class="col-xl-8 col-lg-8 col-12 form-control"></td>
                                                <td>৳ 71000.00</td>
                                                
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="form-group col-12 mg-t-8">
                                    <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Pay Bill</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Add Expense Area End Here -->
                
               
<?php include '../../footer.php';?>