<?php include '../../session.php';?>
<?php include '../../header.php';?>
<?php include '../../topbar.php';?>
<?php include '../../sidebar.php';?>

            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <ul>
                        <li>
                            <a href="../dashboard/index.php">Transactions</a>
                        </li>
                        <li>Purchases</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Teacher Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h5>View Purchases</h5>
                            </div>
                             <a href="/login/transactions/purchases/create.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Create Purchases</a>
                        </div>
                        <form class="mg-b-20">
                            <div class="row gutters-8">
                                <div class="col-md-1 col-5">
                                    <div class="form-group">
                                        <select class="form-control">
                                            <option value="">Bulk Action</option>
                                            <option value="1">Delete</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 col-3">
                                    <div class="form-group">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Apply</a>
                                    </div>
                                </div>
                                <div class="col-md-7 col-4"></div>
                                <div class="col-md-2 col-8">
                                    <div class="form-group">
                                        <input type="text" placeholder="Search by Title ..." class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-1 col-4">
                                    <div class="form-group float-right">
                                        <a href="/login/category/add.php" class="btn-fill-lg bg-blue-dark btn-hover-yellow"> Search</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input checkAll">
                                                <label class="form-check-label">ID</label>
                                            </div>
                                        </th>
                                        <th>Supplier</th>
                                        <th>Reference</th>
                                        <th>Date</th>
                                        <th>Total Amount</th>
                                        <th>Payment Method</th>
                                        <th>Payment From</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#1</label>
                                            </div>
                                        </td>
                                        <td>Alamin Shipping</td>
                                        <td>2021</td>
                                        <td>02/03/2020</td>
                                        <td>৳15,000.00</td>
                                        <td>n/a</td>
                                        <td>n/a</td>
                                        <td style="color:red;">Pending</td>
                                         <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/transactions/purchases/pay-bill.php"><i class="fas fa-check text-dark-pastel-green"></i>Pay Bill</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/#.php"><i class="fas fa-times text-orange-grey"></i>Mark Cancelled</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/view.php"><i class="fas fa-eye text-dark-pastel-green"></i>View</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/edit.php"><i class="fas fa-edit"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-trash-alt text-orange-red"></i></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#2</label>
                                            </div>
                                        </td>
                                        <td>Jamal Steel</td>
                                        <td>2022</td>
                                        <td>02/03/2020</td>
                                        <td>৳10,000.00</td>
                                        <td>Bank Payment</td>
                                        <td>Social Islami Bank</td>
                                        <td style="color:green;">Cleared</td>
                                         <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/transactions/purchases/#.php"><i class="fas fa-times text-orange-grey"></i>Mark Cancelled</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/view.php"><i class="fas fa-eye text-dark-pastel-green"></i>View</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/edit.php"><i class="fas fa-edit"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-trash-alt text-orange-red"></i></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><div class="form-check">
                                                <input type="checkbox" class="form-check-input">
                                                <label class="form-check-label">#3</label>
                                            </div>
                                        </td>
                                        <td>Alamin Shipping</td>
                                        <td>2021</td>
                                        <td>02/03/2020</td>
                                        <td>৳15,000.00</td>
                                        <td>Bank Payment</td>
                                        <td>Social Islami Bank</td>
                                        <td style="color:#888;">Cancelled</td>
                                         <td>
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="/login/transactions/purchases/#.php"><i class="fas fa-times text-orange-grey"></i>Mark Pending</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/view.php"><i class="fas fa-eye text-dark-pastel-green"></i>View</a>
                                                    <a class="dropdown-item" href="/login/transactions/purchases/edit.php"><i class="fas fa-edit"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-trash-alt text-orange-red"></i></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Teacher Table Area End Here -->

<?php include '../../footer.php';?>
